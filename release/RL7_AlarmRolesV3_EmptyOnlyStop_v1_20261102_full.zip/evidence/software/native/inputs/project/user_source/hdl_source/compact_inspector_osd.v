// Shared R13 UI: one ASCII, seven CJK glyphs, unchanged Anlogic logo,
// one sequential decimal formatter. No classifier or recorder decisions here.
// The text plane is complete before row8. Snapshot is the first active pixel,
// after DDR metadata has settled. RGB/DE/HS/VS have the original three clocks.
module compact_inspector_osd #(parameter DEMO_UI=0,FIVE_EMPTY_V7=0,ADJACENT_V6=0,RELAY_CLEAN_UI=0,RELAY_KEYS_V3=0,RELAY_LEFT_LAYOUT=0,AUTO_RELAY=0,RELAY_TARGET_X=760,RELAY_ADVANCE_PX=24,RELAY_TOL_PX=8,BUILD_R22=0,EMPTY_TRACE=0,BUILD_R20=0,BUILD_R19=0,BUILD_R18=0,BUILD_R17=0,REVIEW_PROBE=0,WIDTH=1280,HEIGHT=720,DIAG_BITS=27,ENABLE=1,REPORT_NUMBER_GAPS=1)(
 input wire latency_new,latency_valid,input wire [15:0] latency_ms10,latency_frame_lag,
 input wire [39:0] latency_source_bcd,
 input wire clk,rst_n,vs,hs,de,input wire [23:0] rgb,input wire page,
 input wire [15:0] exposure,gain,fps,width,height,
 input wire [7:0] wb_r,wb_b,roi_mean,roi_min,roi_max,
 input wire wb_tune,wb_pending,roi_valid,cfg_done,
 input wire [1:0] view_mode,input wire [12:0] edge_count,
 input wire [15:0] lane_errors,format_errors,i2c_errors,gaps,overflow_frames,lost_frames,underflow_frames,
 input wire [31:0] frames,input wire [35:0] diagnostics,input wire [DIAG_BITS-1:0] publish_diagnostic,
 input wire [303:0] objects,input wire [127:0] calibration_record,input wire calibration_valid,
 input wire [3:0] local_wait_reason,
 input wire [63:0] relay_status,input wire [95:0] relay_diagnostic,input wire [2:0] relay_control_mode,
 input wire [255:0] live_record,frame_record,input wire eligible,
 output reg out_vs,out_hs,out_de,output reg [23:0] out_rgb
);
reg latency_ok_s;reg [15:0] latency_s,lag_s;reg [39:0] source_bcd_s;
reg [63:0] relay_snapshot;reg [95:0] diagnostic_snapshot;reg [2:0] relay_mode_snapshot;
function [7:0] relay_char;
 input [5:0] char_index;reg [383:0] text;
 begin
  text="RLY S0 F0 Q0 ID000 X000 T000 A000               ";
  // Status numerals are hexadecimal; target/advance are processing pixels.
  if(RELAY_LEFT_LAYOUT)begin
   text="RL2 S0 F0 Q00 N000 X--- L000 V0 T000 A000 W0000 ";
   case(char_index)
    2:relay_char=FIVE_EMPTY_V7 ? "7" : ADJACENT_V6 ? "6" : RELAY_CLEAN_UI ? "5" : RELAY_KEYS_V3 ? (RELAY_TOL_PX>8 ? "4" : "3") : "2";
    5:relay_char=hexchar({1'b0,relay_snapshot[31:29]});
    8:relay_char=hexchar(relay_snapshot[28:25]);
    11:relay_char=hexchar({2'b0,relay_snapshot[63:62]});12:relay_char=hexchar(relay_snapshot[61:58]);
    15:relay_char=hexchar({3'b0,relay_snapshot[20]});16:relay_char=hexchar(relay_snapshot[19:16]);17:relay_char=hexchar(relay_snapshot[15:12]);
    20:relay_char=relay_snapshot[57] ? hexchar({1'b0,relay_snapshot[11:9]}) : "-";
    21:relay_char=relay_snapshot[57] ? hexchar(relay_snapshot[8:5]) : "-";
    22:relay_char=relay_snapshot[57] ? hexchar(relay_snapshot[4:1]) : "-";
    25:relay_char=hexchar({3'b0,relay_snapshot[56]});26:relay_char=hexchar(relay_snapshot[55:52]);27:relay_char=hexchar(relay_snapshot[51:48]);
    30:relay_char=relay_snapshot[57] ? "1" : "0";
    33:relay_char=hexchar((RELAY_TARGET_X>>8)&15);34:relay_char=hexchar((RELAY_TARGET_X>>4)&15);35:relay_char=hexchar(RELAY_TARGET_X&15);
    38:relay_char=hexchar((RELAY_ADVANCE_PX>>8)&15);39:relay_char=hexchar((RELAY_ADVANCE_PX>>4)&15);40:relay_char=hexchar(RELAY_ADVANCE_PX&15);
    43:relay_char=hexchar(relay_snapshot[47:44]);44:relay_char=hexchar(relay_snapshot[43:40]);45:relay_char=hexchar(relay_snapshot[39:36]);46:relay_char=hexchar(relay_snapshot[35:32]);
    default:relay_char=char_index<48 ? text[383-char_index*8-:8] : 8'd32;
   endcase
  end else case(char_index)
   5:relay_char=hexchar({1'b0,relay_snapshot[31:29]});
   8:relay_char=hexchar(relay_snapshot[28:25]);
   11:relay_char=hexchar(relay_snapshot[24:21]);
   15:relay_char=hexchar({3'd0,relay_snapshot[20]});
   16:relay_char=hexchar(relay_snapshot[19:16]);17:relay_char=hexchar(relay_snapshot[15:12]);
   20:relay_char=hexchar({1'b0,relay_snapshot[11:9]});21:relay_char=hexchar(relay_snapshot[8:5]);22:relay_char=hexchar(relay_snapshot[4:1]);
   25:relay_char=hexchar((RELAY_TARGET_X>>8)&15);26:relay_char=hexchar((RELAY_TARGET_X>>4)&15);27:relay_char=hexchar(RELAY_TARGET_X&15);
   30:relay_char=hexchar((RELAY_ADVANCE_PX>>8)&15);31:relay_char=hexchar((RELAY_ADVANCE_PX>>4)&15);32:relay_char=hexchar(RELAY_ADVANCE_PX&15);
   default:relay_char=char_index<48 ? text[383-char_index*8-:8] : 8'd32;
  endcase
 end
endfunction
function [7:0] relay_diag_char;
 input [6:0] ci;reg [423:0] text;
 begin
  text="RD Z0 E0 F0 R0000 N000 T00000000 A00 D00 C00 S0 W0 U0";
  case(ci)
   4:relay_diag_char=hexchar({3'd0,diagnostic_snapshot[95]});
   7:relay_diag_char=hexchar({1'd0,diagnostic_snapshot[94:92]});
   10:relay_diag_char=hexchar(diagnostic_snapshot[3:0]);
   13:relay_diag_char=hexchar(diagnostic_snapshot[91:88]);
   14:relay_diag_char=hexchar(diagnostic_snapshot[87:84]);
   15:relay_diag_char=hexchar(diagnostic_snapshot[83:80]);
   16:relay_diag_char=hexchar(diagnostic_snapshot[79:76]);
   19:relay_diag_char=hexchar({3'd0,diagnostic_snapshot[35]});
   20:relay_diag_char=hexchar(diagnostic_snapshot[34:31]);
   21:relay_diag_char=hexchar(diagnostic_snapshot[30:27]);
   24:relay_diag_char=hexchar(diagnostic_snapshot[67:64]);
   25:relay_diag_char=hexchar(diagnostic_snapshot[63:60]);
   26:relay_diag_char=hexchar(diagnostic_snapshot[59:56]);
   27:relay_diag_char=hexchar(diagnostic_snapshot[55:52]);
   28:relay_diag_char=hexchar(diagnostic_snapshot[51:48]);
   29:relay_diag_char=hexchar(diagnostic_snapshot[47:44]);
   30:relay_diag_char=hexchar(diagnostic_snapshot[43:40]);
   31:relay_diag_char=hexchar(diagnostic_snapshot[39:36]);
   34:relay_diag_char=hexchar(diagnostic_snapshot[75:72]);
   35:relay_diag_char=hexchar(diagnostic_snapshot[71:68]);
   38:relay_diag_char=hexchar(diagnostic_snapshot[19:16]);
   39:relay_diag_char=hexchar(diagnostic_snapshot[15:12]);
   42:relay_diag_char=hexchar(diagnostic_snapshot[11:8]);
   43:relay_diag_char=hexchar(diagnostic_snapshot[7:4]);
   46:relay_diag_char=hexchar({1'd0,diagnostic_snapshot[26:24]});
   49:relay_diag_char=hexchar(diagnostic_snapshot[23:20]);
   52:relay_diag_char=hexchar({1'b0,relay_mode_snapshot});
   default:relay_diag_char=ci<53 ? text[423-ci*8-:8] : 8'd32;
  endcase
 end
endfunction

function [7:0] alarm_char;
 input [6:0] ci;reg [295:0] text;
 begin text="ALARM 5 EMPTY - MOTOR STOP - K3 CLEAR";alarm_char=ci<37 ? text[295-ci*8-:8] : 8'd32;end
endfunction
wire five_empty_alarm=FIVE_EMPTY_V7 && relay_snapshot[31:29]==4 && relay_snapshot[28:25]==15;
reg de_d;reg [10:0] x;reg [9:0] y;
wire start=de && !de_d && y==0;
reg page_s,eligible_s,show,cal_s,gray_s,cfg_s,tune_s,pending_s;
reg [1:0] mode_s;reg [3:0] wait_s;
reg [255:0] live,record;reg [303:0] obs;reg [127:0] cal;
reg [15:0] ex,ga,fp,iw,ih,wr,wb,gm,gn,gx,ec;
reg [15:0] le,fe,ie,gp,ofl,ufl,lost;
reg [31:0] fr,pub;reg [35:0] diag;
reg [75:0] primary;reg [2:0] np,ne,nu;
wire [19:0] cache[0:31];reg [19:0] label_bcd0,label_bcd1;reg [4:0] fmt,step;
reg [15:0] number,next_number;reg [19:0] bcd,adjusted;
reg formatting,feeding,write_valid,ready;
reg [9:0] cursor,write_cursor;
wire [9:0] token;reg [7:0] decoded;
reg [19:0] plane[0:1023];
genvar cache_word;
generate for(cache_word=0;cache_word<32;cache_word=cache_word+1)begin : numeric_cache_view
 assign cache[cache_word]=plane[896+cache_word];
end endgenerate
reg [9:0] token_d,write_cursor_d;reg write_valid_d;
wire cache_write=rst_n && !start && formatting && step==16;
wire text_write=rst_n && !start && write_valid_d;
always @(posedge clk)begin
 if(cache_write)plane[{5'd28,fmt}]<={adjusted[18:0],number[15]};
 else if(text_write)plane[write_cursor_d]<={12'd0,decoded};
end
// Predict exactly the next x/y register state, so a synchronous text-plane
// read is available for the SAME pixel as the former asynchronous lookup.
// Text is finalized before ready exposes it; fonts and the RGB/control
// output pipeline retain their original clocks. No display content removed.
wire [10:0] plane_next_x=vs ? 11'd0 : de ? x+11'd1 : de_d ? 11'd0 : x;
wire [9:0] plane_next_y=vs ? 10'd0 : !de && de_d ? y+10'd1 : y;
wire [10:0] plane_next_dx=plane_next_x-11'd136;
wire [2:0] plane_next_line=
 (plane_next_y>=32 && plane_next_y<56) ? 3'd1 :
 (plane_next_y>=56 && plane_next_y<72) ? 3'd2 :
 (plane_next_y>=8 && plane_next_y<32) ? 3'd0 :
 (plane_next_y>=HEIGHT-88 && plane_next_y<HEIGHT-64) ? 3'd3 :
 (plane_next_y>=HEIGHT-64 && plane_next_y<HEIGHT-40) ? 3'd4 :
 (plane_next_y>=HEIGHT-40 && plane_next_y<HEIGHT-16) ? 3'd5 :
 (plane_next_y>=HEIGHT-16) ? 3'd6 : 3'd0;
wire [9:0] plane_next_address={plane_next_line,plane_next_dx[9:3]};
reg [19:0] plane_q;
wire [9:0] shared_read_address=(feeding || write_valid) ? {5'd28,token[7:3]} : plane_next_address;
always @(posedge clk)plane_q<=plane[shared_read_address];

compact_template_rom #(.BUILD_R22(BUILD_R22),.EMPTY_TRACE(EMPTY_TRACE),.BUILD_R20(BUILD_R20),.BUILD_R19(BUILD_R19),.BUILD_R18(BUILD_R18),.BUILD_R17(BUILD_R17),.REVIEW_PROBE(REVIEW_PROBE)) template_font(clk,{page_s,cursor},token);
// R15 production suppresses numbering-confidence UI only; classification
// colours and LOST/HOLD/CHECK state protection remain active.
wire [8:0] gap_id=!REPORT_NUMBER_GAPS ? 9'd0 : live[57] ? live[102:94] : live[120:112];
wire [8:0] frame_gap=!REPORT_NUMBER_GAPS ? 9'd0 : record[57] ? record[102:94] : record[120:112];
function [2:0] observations;
 input [303:0] data;input [1:0] kind;integer t;
 begin observations=0;for(t=0;t<4;t=t+1)
  if(data[t*76+75] && data[t*76+73+:2]==kind)observations=observations+1'b1;
 end
endfunction
function [7:0] hexchar;
 input [3:0] value;begin hexchar=value<10 ? "0"+value : "A"+value-10;end
endfunction
// Packed strings are always eight characters, indexed from the right.
function [7:0] state_char;
 input [2:0] pos;reg [63:0] word;
 begin
  case(live[50:48])
   0:word="READY   ";1:word="LOCKING ";
   2:word=gap_id!=0 ? "RUN GAP " : "RUN     ";3:word="LOST    ";
   4:word="DONE    ";5:word="HOLD    ";6:word="CHECK   ";default:word="?       ";
  endcase
  state_char=word[pos*8+:8];
 end
endfunction
// Each Chinese glyph occupies three adjacent eight-pixel text cells.
function [7:0] class_char;
 input [1:0] kind;input review;input [3:0] glyph_cell;
 reg [2:0] glyph;reg [1:0] offset;
 begin
  glyph=0;offset=0;
  if(glyph_cell<3)begin offset=glyph_cell;glyph=kind==3 ? 3 : kind==2 && !review ? 1 : 5;end
  else if(glyph_cell<6)begin offset=glyph_cell-3;glyph=kind==3 ? 4 : kind==2 && !review ? 2 : 6;end
  else if(glyph_cell<9 && (kind!=2 && kind!=3 || review))begin offset=glyph_cell-6;glyph=7;end
  class_char=glyph==0 ? 8'd32 : (8'h80 | {2'd0,offset,4'd0} | {5'd0,glyph});
 end
endfunction
// Diagnostic codes describe actual rejection, never alter a decision.
function [3:0] trace_reason;
 input [63:0] c;
 begin
  if(c[0])trace_reason=15;
  else if(!c[1])trace_reason=13;
  else if(!c[63])trace_reason=0;
  else if(c[2] || c[31:24]<6 || c[41:37]<3 || c[36:32]<3)trace_reason=1;
  else if(c[9])trace_reason=5;
  else if(c[8])trace_reason=6;
  else if(!c[13])trace_reason=2;
  else if(!c[10] && c[23:21]>5)trace_reason=4;
  else if(c[3])trace_reason=10;
  else if(c[5] && !c[4])trace_reason=9;
  else if(!c[12] && !c[11] && !c[7])trace_reason=3;
  else if(c[7] && !c[6])trace_reason=8;
  else trace_reason=7;
 end
endfunction
function [31:0] hexvalue;
 input [4:0] slot;reg [63:0] c;
 begin
  c=slot>=23 ? cal[127:64] : cal[63:0];hexvalue=0;
  case(slot)
   0:hexvalue=record[31:0];1:hexvalue=fr;2:hexvalue={16'd0,live[255:240]};
   3:hexvalue=ofl;4:hexvalue=ufl;5:hexvalue=lost;6:hexvalue=le;7:hexvalue=fe;
   8:hexvalue=ie;9:hexvalue=gp;10:hexvalue=diag[31:0];11:hexvalue=pub;12:hexvalue={28'd0,diag[35:32]};
   13:hexvalue=wait_s;14:hexvalue=live[216:213];
   16,23:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {24'd0,c[63:61],1'b0,c[60:57]} : {24'd0,c[59:52]}) : 0;
   17,24:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {24'd0,c[39:32]} : {24'd0,c[51:44]}) : 0;
   18,25:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {24'd0,c[31:24]} : {24'd0,c[43:36]}) : 0;
   19,26:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {24'd0,c[23:16]} : {25'd0,c[13:7]}) : 0;
   20,27:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {24'd0,c[15:8]} : {25'd0,c[6:0]}) : 0;
   21,28:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {24'd0,c[7:0]} : {19'd0,c[26:14]}) : 0;
   22,29:hexvalue=cal_s && c[63] ? (REVIEW_PROBE ? {16'd0,c[56:41]} : {31'd0,c[62]}) : 0;
  endcase
  if(EMPTY_TRACE && slot>=16 && slot<=29)begin
   case(slot>=23 ? slot-7 : slot)
    16:hexvalue={21'd0,c[62:52]};17:hexvalue={22'd0,c[51:42]};
    18:hexvalue={16'd0,3'd0,c[41:37],3'd0,c[36:32]};
    19:hexvalue={24'd0,c[31:24]};20:hexvalue={20'd0,1'b0,c[23:21],2'd0,c[20:15]};
    21:hexvalue={17'd0,c[14:0]};22:hexvalue={28'd0,trace_reason(c)};
   endcase
  end
 end
endfunction
function [7:0] special_char;
 input [4:0] slot;input [2:0] pos;reg [127:0] message;
 begin
  special_char=32;message="IDS UNCONFIRMED ";
  case(slot)
   1:special_char=state_char(pos);
   2:special_char=hexchar(live[54:51]);
   3:special_char=!live[55] ? "?" : live[56] ? "R" : "L";
   4:special_char="1"+live[57];5:special_char=(page_s ? eligible_s : gray_s) ? "1" : "0";
   6:special_char=cfg_s ? "1" : "0";7:special_char="0"+mode_s;
   8:special_char=pending_s ? "*" : tune_s ? "T" : "L";
   9:special_char="0"+np;
   10:special_char=gap_id!=0 ? ("GAP FROM" >> (pos*8)) : 8'd32;
   11:special_char=gap_id!=0 ? "R" : "N";
   12:special_char=gap_id!=0 ? message[127-(7-pos)*8-:8] : 8'd32;
   13:special_char=live[210:202]!=0 ? class_char(live[212:211],live[212:211]==2 && live[216:213]!=0,7-pos) : 8'd32;
   14:special_char="0"+ne;
   15:special_char="0"+nu;
   16:special_char=cal_s ? "1" : "0";
   17:special_char=gap_id!=0 ? message[127-(14-pos)*8-:8] : 8'd32;
   18:special_char=live[210:202]!=0 ? class_char(live[212:211],live[212:211]==2 && live[216:213]!=0,8) : 8'd32;
   19:special_char=gap_id!=0 ? "R" : " ";
  endcase
 end
endfunction
wire [31:0] hexadecimal=hexvalue(token_d[7:3]);
always @*begin
 case(token_d[9:8])
  0:decoded=token_d[7:0];
  1:decoded=token_d[7:3]==20 && gap_id==0 ? 8'd32 : "0"+((plane_q>>(token_d[2:0]*4))&4'hf);
  2:decoded=hexchar(hexadecimal>>(token_d[2:0]*4));
  default:decoded=special_char(token_d[7:3],token_d[2:0]);
 endcase
 next_number=0;
 case(fmt)
  0:next_number={7'd0,live[66:58]};1:next_number={7'd0,live[75:67]};
  2:next_number={7'd0,live[84:76]};3:next_number={7'd0,live[93:85]};
  4:next_number=live[239:224];5:next_number={7'd0,live[210:202]};
  // Constant slices avoid an arithmetic address and variable-wide record read.
  6:next_number={7'd0,live[130+:9]};
  7:next_number={7'd0,live[139+:9]};
  8:next_number={7'd0,live[148+:9]};
  9:next_number={7'd0,live[157+:9]};
  10:next_number={7'd0,live[166+:9]};
  11:next_number={7'd0,live[175+:9]};
  12:next_number={7'd0,live[184+:9]};
  13:next_number={7'd0,live[193+:9]};
  14:next_number=ex;15:next_number=ga;16:next_number=fp;
  17:next_number={10'd0,live[222:217]}+1'b1;
  18:next_number={7'd0,record[57] ? record[112+:9] : record[94+:9]};
  19:next_number={7'd0,record[57] ? record[121+:9] : record[103+:9]};
  20:next_number={7'd0,gap_id};21:next_number=wr;22:next_number=wb;
  23:next_number=gm;24:next_number=gn;25:next_number=gx;
  26:next_number={9'd0,primary[55:49]};27:next_number={9'd0,primary[48:42]};
  28:next_number={3'd0,primary[68:56]};29:next_number=iw;30:next_number=ih;31:next_number=ec;
 endcase
 if(DEMO_UI)begin
  // Demo categories are disjoint: normal PRESENT = all PRESENT - REVIEW.
  // Backend counters/events remain untouched.
  if(fmt==1)next_number=live[75:67]>=live[93:85] ? live[75:67]-live[93:85] : 0;
  if(fmt==23)next_number=latency_s;
  if(fmt==24)next_number=lag_s;
 end
 adjusted=bcd;
 if(bcd[3:0]>=5)adjusted[3:0]=bcd[3:0]+3;
 if(bcd[7:4]>=5)adjusted[7:4]=bcd[7:4]+3;
 if(bcd[11:8]>=5)adjusted[11:8]=bcd[11:8]+3;
 if(bcd[15:12]>=5)adjusted[15:12]=bcd[15:12]+3;
 if(bcd[19:16]>=5)adjusted[19:16]=bcd[19:16]+3;
end
// Demo labels represent the taught pocket row. Unknown off-row contours
// (including phase-eroded feed holes) are not inspected component labels.
// Confirmed PRESENT/review and EMPTY stay visible at every row; no counter
// or classifier record is altered by this presentation-only role filter.
function label_role_allowed;input [75:0] value;reg [10:0] twice_y;
 begin
  twice_y={1'b0,value[19:10]}+value[9:0];
  label_role_allowed=!DEMO_UI || !RELAY_LEFT_LAYOUT || value[74:73]>=2 ||
   (value[74:73]==1 && twice_y>=HEIGHT/3+HEIGHT*5/9-32 && twice_y<=HEIGHT/3+HEIGHT*5/9+32);
 end
endfunction
// The role bit is captured atomically with its object, outside the pixel path.
reg [3:0] label_roles;integer role_slot;
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  latency_ok_s<=0;latency_s<=0;lag_s<=0;source_bcd_s<=0;
  relay_snapshot<=0;diagnostic_snapshot<=0;relay_mode_snapshot<=0;
  de_d<=0;x<=0;y<=0;page_s<=0;eligible_s<=0;show<=0;cal_s<=0;gray_s<=0;cfg_s<=0;tune_s<=0;pending_s<=0;
  mode_s<=0;wait_s<=0;live<=0;record<=0;obs<=0;label_roles<=0;cal<=0;primary<=0;np<=0;ne<=0;nu<=0;
  ex<=0;ga<=0;fp<=0;iw<=0;ih<=0;wr<=0;wb<=0;gm<=0;gn<=0;gx<=0;ec<=0;
  le<=0;fe<=0;ie<=0;gp<=0;ofl<=0;ufl<=0;lost<=0;fr<=0;pub<=0;diag<=0;
  token_d<=0;write_cursor_d<=0;write_valid_d<=0;fmt<=0;step<=0;number<=0;bcd<=0;formatting<=0;feeding<=0;write_valid<=0;ready<=0;cursor<=0;write_cursor<=0;
 end else begin
  de_d<=de;
  if(vs)begin x<=0;y<=0;end
  else if(de)x<=x+1'b1;else if(de_d)begin x<=0;y<=y+1'b1;end
  if(start)begin
   if(DEMO_UI)begin latency_ok_s<=0;latency_s<=0;lag_s<=0;source_bcd_s<=0;end
   relay_snapshot<=relay_status;diagnostic_snapshot<=relay_diagnostic;relay_mode_snapshot<=relay_control_mode;
   page_s<=page;live<=live_record;record<=frame_record;obs<=objects;cal<=calibration_record;
   for(role_slot=0;role_slot<4;role_slot=role_slot+1)label_roles[role_slot]<=label_role_allowed(objects[role_slot*76+:76]);
   eligible_s<=eligible;cal_s<=calibration_valid;gray_s<=roi_valid;cfg_s<=cfg_done;tune_s<=wb_tune;pending_s<=wb_pending;
   show<=eligible && frame_record[47:32]==live_record[47:32] &&
    (frame_record[50:48]==1 || frame_record[50:48]==2 || frame_record[50:48]==5) &&
    (live_record[50:48]==1 || live_record[50:48]==2 || live_record[50:48]==5);
   ex<=exposure;ga<=gain;fp<=fps;iw<=width;ih<=height;wr<={8'd0,wb_r};wb<={8'd0,wb_b};
   gm<=roi_valid ? {8'd0,roi_mean} : 0;gn<=roi_valid ? {8'd0,roi_min} : 0;gx<=roi_valid ? {8'd0,roi_max} : 0;ec<={3'd0,edge_count};
   primary<=frame_record[57] ? (objects[227] ? objects[227:152] : objects[303:228]) : (objects[75] ? objects[75:0] : objects[151:76]);
   np<=observations(objects,2);ne<=observations(objects,3);nu<=observations(objects,1);
   le<=lane_errors;fe<=format_errors;ie<=i2c_errors;gp<=gaps;ofl<=overflow_frames;ufl<=underflow_frames;lost<=lost_frames;
   fr<=frames;pub<=publish_diagnostic;diag<=diagnostics;mode_s<=view_mode;wait_s<=local_wait_reason;
   token_d<=0;write_cursor_d<=0;write_valid_d<=0;fmt<=0;step<=0;formatting<=1;feeding<=0;write_valid<=0;ready<=0;cursor<=0;
  end else begin
   // A current-raster measurement is produced32 clocks after the real HDMI
   // first pixel. Snapshot it before cache slots23/24 are formatted; row8
   // displays this SAME raster's coherent source/latency tuple.
   if(DEMO_UI && latency_new && formatting && fmt<23)begin
    latency_ok_s<=latency_valid;latency_s<=latency_ms10;lag_s<=latency_frame_lag;source_bcd_s<=latency_source_bcd;
   end
   if(formatting)begin
    if(step==0)begin number<=next_number;bcd<=0;step<=1;end
    else begin
     number<={number[14:0],1'b0};bcd<={adjusted[18:0],number[15]};
     if(step==16)begin
      if(fmt==18)label_bcd0<={adjusted[18:0],number[15]};
      if(fmt==19)label_bcd1<={adjusted[18:0],number[15]};step<=0;
      if(fmt==31)begin formatting<=0;feeding<=1;cursor<=0;end else fmt<=fmt+1'b1;
     end else step<=step+1'b1;
    end
   end
   write_valid<=feeding;write_valid_d<=write_valid;write_cursor_d<=write_cursor;token_d<=token;
   if(feeding)begin write_cursor<=cursor;if(cursor==895)feeding<=0;else cursor<=cursor+1'b1;end
   if(write_valid_d && write_cursor_d==895)ready<=1;
  end
 end
end

// Human-facing demo text. Existing fonts, logo, boxes, pixel timing and
// numeric formatter are retained. Debug templates remain available only in
// explicit DEMO_UI=0 compatibility builds.
function [7:0] demo_digit;input [4:0] slot;input [2:0] digit;
 begin demo_digit="0"+((cache[slot]>>(digit*4))&4'hf);end
endfunction
function [7:0] demo_char;
 input [2:0] ln;input [6:0] ci;
 reg [511:0] text;reg [79:0] state_word;reg [6:0] k;
 begin
  demo_char=32;text=0;state_word="READY     ";k=0;
  if(relay_snapshot[31:29]==4)state_word=five_empty_alarm ? "ALARM     " : "FAULT     ";
  else if(relay_mode_snapshot==2)state_word="PAUSED    ";
  else if(relay_mode_snapshot==3)state_word="MANUAL    ";
  else if(relay_mode_snapshot==4)state_word="STOPPED   ";
  else if(relay_mode_snapshot==1)state_word=relay_snapshot[31:29]==3 ? "HOLD 1S   " : "RUNNING   ";
  case(ln)
   0:begin
    if(ci<16)begin text={"INSPECT RL7 DEMO",384'd0};demo_char=text[511-ci*8-:8];end
    if(ci>=28 && ci<32)begin text={"FPS ",480'd0};demo_char=text[511-(ci-28)*8-:8];end
    if(ci>=32 && ci<35)demo_char=demo_digit(16,34-ci);
    if(ci>=37 && ci<46)begin text={"1280X720 ",440'd0};demo_char=text[511-(ci-37)*8-:8];end
    if(ci>=78 && ci<86)begin text={"LATENCY ",448'd0};demo_char=text[511-(ci-78)*8-:8];end
    if(ci>=86 && ci<90)demo_char=latency_ok_s ? demo_digit(23,90-ci) : "-";
    if(ci==90)demo_char=".";
    if(ci==91)demo_char=latency_ok_s ? demo_digit(23,0) : "-";
    if(ci==93)demo_char="m";if(ci==94)demo_char="s";
   end
   1:begin
    if(ci<6)begin text={"TOTAL ",464'd0};demo_char=text[511-ci*8-:8];end
    if(ci>=6 && ci<9)demo_char=demo_digit(0,8-ci);
    if(ci>=16 && ci<22)demo_char=class_char(2,0,ci-16);
    if(ci>=24 && ci<27)demo_char=demo_digit(1,26-ci);
    if(ci>=34 && ci<40)demo_char=class_char(3,0,ci-34);
    if(ci>=42 && ci<45)demo_char=demo_digit(2,44-ci);
    if(ci>=52 && ci<61)demo_char=class_char(2,1,ci-52);
    if(ci>=63 && ci<66)demo_char=demo_digit(3,65-ci);
    if(ci>=78 && ci<88)begin text={"FRAME LAG ",432'd0};demo_char=text[511-(ci-78)*8-:8];end
    if(ci>=88 && ci<91)demo_char=latency_ok_s ? demo_digit(24,90-ci) : "-";
    if(ci>=93 && ci<97)begin text={"SRC ",480'd0};demo_char=text[511-(ci-93)*8-:8];end
    if(ci>=97 && ci<107)demo_char=latency_ok_s ? "0"+((source_bcd_s>>((106-ci)*4))&4'hf) : "-";
   end
   2:begin
    if(ci<6)begin text={"STATE ",464'd0};demo_char=text[511-ci*8-:8];end
    if(ci>=6 && ci<16)demo_char=state_word[79-(ci-6)*8-:8];
    if(ci>=28 && ci<33)begin text={"LAST ",472'd0};demo_char=text[511-(ci-28)*8-:8];end
    if(ci>=33 && ci<36)demo_char=demo_digit(5,35-ci);
    if(ci>=78 && ci<99)begin text={"CAP SOF -> HDMI PIXEL",344'd0};demo_char=text[511-(ci-78)*8-:8];end
    if(five_empty_alarm && ci<37)demo_char=alarm_char(ci);
   end
   3:begin
    if(ci<15)begin text={"EMPTY IDS PAGE ",392'd0};demo_char=text[511-ci*8-:8];end
    if(ci>=15 && ci<18)demo_char=demo_digit(17,17-ci);
    if(ci>=24 && ci<72)begin
     k=ci-24;
     case(k/6)
      0:if(k%6<3)demo_char=demo_digit(6,2-k%6);
      1:if(k%6<3)demo_char=demo_digit(7,2-k%6);
      2:if(k%6<3)demo_char=demo_digit(8,2-k%6);
      3:if(k%6<3)demo_char=demo_digit(9,2-k%6);
      4:if(k%6<3)demo_char=demo_digit(10,2-k%6);
      5:if(k%6<3)demo_char=demo_digit(11,2-k%6);
      6:if(k%6<3)demo_char=demo_digit(12,2-k%6);
      7:if(k%6<3)demo_char=demo_digit(13,2-k%6);
     endcase
    end
   end
   4:begin
    if(five_empty_alarm && ci<37)begin text={"5 EMPTY ALARM - K3 CLEAR OR K1 NEW RUN",208'd0};demo_char=text[511-ci*8-:8];end
   end
   5:begin
    if(ci<47)begin text={"K1 START   K2 PAUSE/RESUME   K3 CLEAR   K4 STOP",136'd0};demo_char=text[511-ci*8-:8];end
   end
   6:if(ci<10)demo_char=state_word[79-ci*8-:8];
  endcase
 end
endfunction

reg [2:0] line;reg [9:0] plane_address;reg [7:0] code;
reg [4:0] row,col;reg panel,guide,logo,repair_border;reg [23:0] ink;
reg [75:0] ob;reg [8:0] id;reg [19:0] id_bcd;
reg [10:0] lx,rx;reg [9:0] ly;reg [3:0] glyph_cell;
wire trace_cross0=EMPTY_TRACE && cal_s && cal[63] &&
 ((x==cal[62:52] && y+4>=cal[51:42] && y<=cal[51:42]+4) ||
  (y==cal[51:42] && x+4>=cal[62:52] && x<=cal[62:52]+4));
wire trace_cross1=EMPTY_TRACE && cal_s && cal[127] &&
 ((x==cal[126:116] && y+4>=cal[115:106] && y<=cal[115:106]+4) ||
  (y==cal[115:106] && x+4>=cal[126:116] && x<=cal[126:116]+4));
reg prefix;integer t;
// Four hit tests retain last-hit priority; decode the selected label once.
reg label_hit,label_prefix,label_review;reg [1:0] label_kind;
reg [8:0] label_id;reg [19:0] label_digits;
reg [10:0] label_x;reg [9:0] label_y;
wire [10:0] text_dx=x-11'd136;
always @*begin
 line=0;plane_address=0;code=32;row=0;col=0;panel=0;guide=0;logo=0;repair_border=0;ink=24'h70ffdd;
 ob=0;id=0;id_bcd=0;lx=0;rx=0;ly=0;glyph_cell=0;prefix=0;
 label_hit=0;label_prefix=0;label_review=0;label_kind=0;
 label_id=0;label_digits=0;label_x=0;label_y=0;
 if(y<80 || y>=HEIGHT-96)begin
  panel=1;logo=x>=16 && x<112 && y>=8 && y<72;
  if(x>=136 && x<1160 && ready)begin
   if(y>=8 && y<32)begin line=0;row=y-8;end
   else if(y>=32 && y<56)begin line=1;row=y-32;end
   else if(y>=56 && y<72)begin line=2;row=y-56;end
   else if(y>=HEIGHT-88 && y<HEIGHT-64)begin line=3;row=y-(HEIGHT-88);end
   else if(y>=HEIGHT-64 && y<HEIGHT-40)begin line=4;row=y-(HEIGHT-64);end
   else if(y>=HEIGHT-40 && y<HEIGHT-16)begin line=5;row=y-(HEIGHT-40);end
   else if(y>=HEIGHT-16)begin line=6;row=y-(HEIGHT-16);end
   else row=31;
   plane_address={line,text_dx[9:3]};code=plane_q;col={2'd0,text_dx[2:0]};
   if(code[7])col={code[5:4],3'd0}+text_dx[2:0];
   if(DEMO_UI)begin
    code=demo_char(line,text_dx[9:3]);
    col=code[7] ? {code[5:4],3'd0}+text_dx[2:0] : {2'd0,text_dx[2:0]};
   end
   if(!DEMO_UI && AUTO_RELAY && line==2 && text_dx[9:3]>=72)code=relay_char(text_dx[9:3]-72);
   if(!DEMO_UI && ADJACENT_V6 && line==6)code=relay_diag_char(text_dx[9:3]);
   if(five_empty_alarm && line==2 && text_dx[9:3]<64)begin
    code=alarm_char(text_dx[9:3]);col={2'd0,text_dx[2:0]};ink=24'hff5050;
   end
   if(DEMO_UI && line<=1 && text_dx[9:3]>=78)ink=24'hffd060;
   if(row==31)code=32;
   if(page_s && gap_id!=0 && (line==1 || line==2 || line==3))ink=24'hffe080;
  end
 end else begin
  guide=(((x==WIDTH*5/16 || x==WIDTH*11/16-1) && ((y>=HEIGHT/3 && y<HEIGHT*5/9)||(y>=HEIGHT*3/5 && y<HEIGHT*5/6))) ||
   ((y==HEIGHT/3 || y==HEIGHT*5/9-1 || y==HEIGHT*3/5 || y==HEIGHT*5/6-1) && x>=WIDTH*5/16 && x<WIDTH*11/16)) && (x[3] || y[3]);
  if(x==WIDTH/2 && y[2] && ((y>=HEIGHT/3 && y<HEIGHT*5/9 && (!page_s || !record[57])) ||
   (y>=HEIGHT*3/5 && y<HEIGHT*5/6 && (!page_s || record[57]))))guide=1;
  if(AUTO_RELAY && ((y>=HEIGHT/3 && y<HEIGHT*5/9)||(y>=HEIGHT*3/5 && y<HEIGHT*5/6)) &&
    (x==RELAY_TARGET_X || (x==RELAY_TARGET_X-RELAY_ADVANCE_PX && y[2])))guide=1;
  if(RELAY_LEFT_LAYOUT)begin
   // Same upper tape row: right count gate / left independent repair gate.
   guide=y>=HEIGHT/3 && y<HEIGHT*5/9 &&
    (((x==64 || x==447 || x==448 || x==831) && y[3]) ||
     ((y==HEIGHT/3 || y==HEIGHT*5/9-1) && x>=64 && x<832 && x[3]) ||
     (x==WIDTH/2 && y[2]) || (x==256 && y[3]) ||
     x==RELAY_TARGET_X || (x==RELAY_TARGET_X+RELAY_ADVANCE_PX && y[2]));
  end
  // Amber dashed box is the acceptance window, not a new detection ROI.
  // It changes display only; classification still consumes original pixels.
  if(AUTO_RELAY && RELAY_LEFT_LAYOUT && RELAY_TOL_PX>8)
   repair_border=y>=HEIGHT/3 && y<HEIGHT*5/9 &&
    (((x==RELAY_TARGET_X-RELAY_TOL_PX || x==RELAY_TARGET_X+RELAY_TOL_PX) && y[3]) ||
     ((y==HEIGHT/3 || y==HEIGHT*5/9-1) && x>=RELAY_TARGET_X-RELAY_TOL_PX &&
      x<=RELAY_TARGET_X+RELAY_TOL_PX && x[3]));
  // Production view shows one count ROI and the amber acceptance window.
  // Internal station ROI, gate, prediction and trigger are unchanged.
  if(RELAY_CLEAN_UI && AUTO_RELAY && RELAY_LEFT_LAYOUT)
   guide=y>=HEIGHT/3 && y<HEIGHT*5/9 &&
    (((x==448 || x==831) && y[3]) ||
     ((y==HEIGHT/3 || y==HEIGHT*5/9-1) && x>=448 && x<832 && x[3]));
  if(!RELAY_CLEAN_UI && (trace_cross0 || trace_cross1))guide=1;
  for(t=0;t<4;t=t+1)begin
   ob=obs[t*76+:76];id=0;id_bcd=0;
   if(page_s && t/2==record[57])begin
    id=record[94+t*9+:9];id_bcd=t%2==0 ? label_bcd0 : label_bcd1;
   end
   if(ready && ob[75] && label_roles[t] && (!page_s || eligible_s && t/2==record[57]))begin
    if(((x==ob[41:31] || x==ob[30:20]) && y>=ob[19:10] && y<=ob[9:0]) ||
      ((y==ob[19:10] || y==ob[9:0]) && x>=ob[41:31] && x<=ob[30:20]))guide=1;
    prefix=!DEMO_UI && page_s && show && id!=0;
    lx=ob[41:31]>WIDTH-112 ? WIDTH-112 : ob[41:31];
    ly=t%2==0 ? (ob[19:10]>=108 ? ob[19:10]-28 : 80) : (ob[9:0]<HEIGHT-124 ? ob[9:0]+4 : HEIGHT-120);
    rx=lx+(prefix ? 112 : 72);
    if(x>=lx && x<rx && y>=ly && y<ly+24)begin
     label_hit=1;label_prefix=prefix;label_kind=ob[74:73];
     label_review=ob[74:73]==2 && ob[72:69]!=0;
     label_id=id;label_digits=id_bcd;label_x=lx;label_y=ly;
    end
   end
   if(label_hit)begin
    panel=1;row=y-label_y;glyph_cell=(x-label_x)>>3;col=(x-label_x)&7;
    if(label_prefix && glyph_cell<4)code=glyph_cell==0 ? (frame_gap!=0 && label_id>=frame_gap ? "R" : "N") : "0"+((label_digits>>((3-glyph_cell)*4))&4'hf);
    else if(label_prefix && glyph_cell==4)code=32;
    else code=class_char(label_kind,label_review,label_prefix ? glyph_cell-5 : glyph_cell);
    if(code[7])col={code[5:4],3'd0}+((x-label_x)&7);
    ink=label_kind==3 ? 24'hffe080 : label_kind==2 && !label_review ? 24'h70ffdd : 24'hffb070;
   end
  end
 end
end
reg [10:0] ascii_address;reg [7:0] cjk_address;reg [12:0] logo_address;
wire [7:0] ascii_bits;wire [23:0] cjk_bits;wire [1:0] logo_pixel;
wire [5:0] logo_y=y-10'd8;wire [6:0] logo_x=x-11'd16;
reg [1:0] vp,hp,dp,pp,lp,cp;
generate if(DEMO_UI)begin : shared_font
 rl7_shared_font_rom font(clk,ascii_address,cjk_address,cp[0],ascii_bits,cjk_bits);
end else begin : legacy_fonts
 compact_ascii_rom ascii_font(clk,ascii_address,ascii_bits);
 compact_cjk_rom cjk_font(clk,cjk_address,cjk_bits);
end endgenerate
osd_logo_rom anlogic_logo(clk,logo_address,logo_pixel);reg [4:0] c0,c1;
reg [23:0] rgb0,rgb1,ink0,ink1;
wire text_ink=cp[1] ? c1<24 && cjk_bits[23-c1] : c1<8 && ascii_bits[7-c1];
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin
  ascii_address<=0;cjk_address<=0;logo_address<=0;vp<=0;hp<=0;dp<=0;pp<=0;lp<=0;cp<=0;
  c0<=0;c1<=0;rgb0<=0;rgb1<=0;ink0<=0;ink1<=0;out_vs<=0;out_hs<=0;out_de<=0;out_rgb<=0;
 end else begin
  ascii_address<={code[6:0],row[3:0]};cjk_address<={code[2:0],row};logo_address<={logo_y,logo_x};
  vp<={vp[0],vs};hp<={hp[0],hs};dp<={dp[0],de};pp<={pp[0],ENABLE && panel && de};
  lp<={lp[0],logo};cp<={cp[0],code[7]};c0<=!code[7] && row>=16 ? 5'd31 : col;c1<=c0;
  rgb0<=ENABLE && repair_border ? 24'hffd060 : ENABLE && guide ? 24'h00d8d0 : rgb;rgb1<=rgb0;ink0<=ink;ink1<=ink0;
  out_vs<=vp[1];out_hs<=hp[1];out_de<=dp[1];
  out_rgb<=pp[1] ? (lp[1] ? (logo_pixel==1 ? 24'h204686 : logo_pixel==2 ? 24'hcc253b : 24'hffffff) :
   text_ink ? ink1 : 24'h142336) : rgb1;
 end
end
endmodule
