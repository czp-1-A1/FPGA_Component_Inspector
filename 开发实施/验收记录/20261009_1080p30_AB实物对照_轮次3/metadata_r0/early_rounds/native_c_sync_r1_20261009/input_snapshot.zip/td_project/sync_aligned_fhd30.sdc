create_clock -name sys_clk_50m -period 20 [get_ports I_sys_clk]
derive_clocks
derive_clock_uncertainty
set_false_path -from [get_ports I_rst_n]
# Async user reset releases via three pixel flops. Four TMDS external output
# budgets remain open; internal STA is not physical signal-integrity proof.
