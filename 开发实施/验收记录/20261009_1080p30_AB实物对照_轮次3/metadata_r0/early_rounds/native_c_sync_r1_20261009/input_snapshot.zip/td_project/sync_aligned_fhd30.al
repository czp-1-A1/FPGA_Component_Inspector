<?xml version="1.0" encoding="UTF-8"?>
<Project Version="3" Minor="2" Path="C:/Users/Li47/Desktop/aa/native_c_sync_r1_20261009/td_project">
    <Project_Created_Time></Project_Created_Time>
    <TD_Encoding>UTF-8</TD_Encoding>
    <TD_Version>6.2.178840</TD_Version>
    <Name>sync_aligned_fhd30</Name>
    <HardWare>
        <Family>PH1</Family>
        <Device>PH1P35MDG324</Device>
        <Speed>-3</Speed>
    </HardWare>
    <Source_Files>
<Verilog>
<File Path="../diagnostics/hdmi_positive/sync_aligned_top.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="1"/>
</FileInfo>
</File>
<File Path="../diagnostics/hdmi_positive/positive_top.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="2"/>
</FileInfo>
</File>
<File Path="../diagnostics/hdmi_positive/dvi_encoder.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="3"/>
</FileInfo>
</File>
<File Path="../user_source/hdl_source/native_hdmi_pll.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="4"/>
</FileInfo>
</File>
<File Path="../user_source/ip_source/PLL/RTL/ph1p_phy_pll_wrapper_25a56e5ce2f9.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="5"/>
</FileInfo>
</File>
<File Path="../user_source/hdl_source/hdmi_phy_warpper.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="6"/>
</FileInfo>
</File>
<File Path="../user_source/hdl_source/lane_lvds_10_1.v">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="design_1"/>
<Attr Name="CompileOrder" Val="7"/>
</FileInfo>
</File>
</Verilog>
<System_Verilog>
</System_Verilog>
<ADC_FILE>
<File Path="pin.adc">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="constraint_1"/>
<Attr Name="CompileOrder" Val="8"/>
</FileInfo>
</File>
</ADC_FILE>
<SDC_FILE>
<File Path="sync_aligned_fhd30.sdc">
<FileInfo>
<Attr Name="UsedInSyn" Val="true"/>
<Attr Name="UsedInP&amp;R" Val="true"/>
<Attr Name="BelongTo" Val="constraint_1"/>
<Attr Name="CompileOrder" Val="9"/>
</FileInfo>
</File>
</SDC_FILE>
<IP_FILE>
</IP_FILE>
</Source_Files>
    <FileSets>
        <FileSet Name="design_1" Type="DesignFiles">
        </FileSet>
        <FileSet Name="constraint_1" Type="ConstrainFiles">
        </FileSet>
    </FileSets>
    <TOP_MODULE>
        <LABEL>sync_aligned_fhd30_top</LABEL>
        <MODULE>sync_aligned_fhd30_top</MODULE>
        <CREATEINDEX>user</CREATEINDEX>
    </TOP_MODULE>
    <Property>
    </Property>
    <Device_Settings>
    </Device_Settings>
    <Configurations>
        <Control0>
            <mclk_freq>33MHz</mclk_freq>
        </Control0>
        <FeatureRow>
            <boot_mode>mspix4</boot_mode>
        </FeatureRow>
    </Configurations>
    <Runs>
        <Run Name="syn_1" Type="Synthesis" ConstraintSet="constraint_1" Description="" Active="true" useDefaultScript="false">
            <Strategy Name="Default_Synthesis_Strategy">
            </Strategy>
            <UserParams>
            </UserParams>
        </Run>
        <Run Name="phy_1" Type="PhysicalDesign" ConstraintSet="constraint_1" Description="" SynRun="syn_1" Active="true">
            <Strategy Name="Default_PhysicalDesign_Strategy">
                <BitgenProperty::GeneralOption>
                    <compress>on</compress>
                </BitgenProperty::GeneralOption>
            </Strategy>
            <UserParams>
            </UserParams>
        </Run>
    </Runs>
    <Project_Settings>
    </Project_Settings>
</Project>
