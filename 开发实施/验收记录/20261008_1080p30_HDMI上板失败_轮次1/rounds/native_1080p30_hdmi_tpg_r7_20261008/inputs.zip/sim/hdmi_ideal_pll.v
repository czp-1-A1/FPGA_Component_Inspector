`timescale 1ns/1fs
// Test environment only. Never included in the diagnostic TD project.
// The actual vendor PLL is verified separately; this model isolates the
// full-frame encrypted HDMI/ODDR raster from analog/VCO simulation cost.
module HDMI_PLL(input refclk,output reg clk0_out,clk1_out,output lock,input reset);
 initial begin clk0_out=0;clk1_out=0;end
 // Exact integer 5:1 in simulator ticks. Independent rounded periods with
 // a 1 fs discrepancy drift into a serializer load-boundary slip at ~9 ms.
 always #6.734006735 clk0_out=~clk0_out;
 always #1.346801347 clk1_out=~clk1_out;
 assign lock=!reset;
endmodule
