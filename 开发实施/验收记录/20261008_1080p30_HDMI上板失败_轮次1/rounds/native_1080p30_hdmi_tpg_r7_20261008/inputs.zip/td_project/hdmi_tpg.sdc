create_clock -name sys_clk_50m -period 20 [get_ports I_sys_clk]
derive_clocks
derive_clock_uncertainty
# User reset is an asynchronous control; release is synchronized in pixel.
set_false_path -from [get_ports I_rst_n]
# This diagnostic does not claim a board-level TMDS external timing budget.
# Four TMDS outputs remain explicitly open in check_timing coverage.
