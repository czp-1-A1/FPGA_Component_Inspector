create_clock -name sys_clk_50m -period 20 [get_ports I_sys_clk]
derive_clocks
derive_clock_uncertainty
set_false_path -from [get_ports I_rst_n]
# SW1 is asynchronous. Cut only its first synchronizer input.
set_false_path -from [get_ports I_mode_select] -to [get_regs {mode_s0}]
# Constrain synchronizer stage proximity; stage2 stays normally timed.
set_max_delay -datapath_only 2.0 -from [get_regs {mode_s0}] -to [get_regs {mode_s1}]
# Registered Gray buses: bound each transition below one source pixel period.
set_max_delay -datapath_only 12.0 -from [get_regs {u_count.p_gray* u_count.h_gray* u_count.v_gray*}] -to [get_regs {u_measure.p_s0* u_measure.h_s0* u_measure.v_s0*}]
set_max_delay -datapath_only 2.0 -from [get_regs {u_measure.*_s0*}] -to [get_regs {u_measure.*_s1*}]
set_false_path -from [get_pins {u_pll/u_ref/ph1p_phy_pll_wrapper_25a56e5ce2f9_Inst/u_PH1P_PHY_PLL.lock u_pll/u_output/ph1p_phy_pll_wrapper_25a56e5ce2f9_Inst/u_PH1P_PHY_PLL.lock}] -to [get_regs {u_measure.lock_s0}]
set_max_delay -datapath_only 8.0 -from [get_regs {frame_mode}] -to [get_regs {u_measure.mode_s0}]
# Held mailbox payload/tokens, with synchronizer stage proximity.
# Keep normal hold checks even on Gray/mailbox crossings: packed-cell aliases
# can also select intra-domain flops. Datapath max budgets only tighten setup.
set_max_delay -datapath_only 8.0 -from [get_regs {u_status.payload* u_status.req u_status.ack}] -to [get_regs {u_status.D_data* u_status.req_sync[0] u_status.ack_sync[0]}]
set_max_delay -datapath_only 2.0 -from [get_regs {u_status.req_sync[0] u_status.ack_sync[0]}] -to [get_regs {u_status.req_sync[1] u_status.ack_sync[1]}]
# Three pixel flops release asynchronous reset. Four TMDS board output
# budgets remain open; internal STA is not physical signal-integrity proof.
