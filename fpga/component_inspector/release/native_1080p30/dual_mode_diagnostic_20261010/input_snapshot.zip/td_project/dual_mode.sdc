create_clock -name sys_clk_50m -period 20 [get_ports I_sys_clk]
derive_clocks
derive_clock_uncertainty
set_false_path -from [get_ports I_rst_n]
# SW1 is asynchronous. Cut only its first synchronizer input.
set_false_path -from [get_ports I_mode_select] -to [get_regs {mode_s0}]
# Constrain synchronizer stage proximity; stage2 stays normally timed.
set_max_delay -datapath_only 2.0 -from [get_regs {mode_s0}] -to [get_regs {mode_s1}]
# Three pixel flops release asynchronous reset. Four TMDS board output
# budgets remain open; internal STA is not physical signal-integrity proof.
