create_clock -name sys_clk_50m -period 20 [get_ports I_sys_clk]
derive_clocks
derive_clock_uncertainty
set_false_path -from [get_ports I_rst_n]
# Three pixel flops release asynchronous reset. Four TMDS board output
# budgets remain open; internal STA is not physical signal-integrity proof.
