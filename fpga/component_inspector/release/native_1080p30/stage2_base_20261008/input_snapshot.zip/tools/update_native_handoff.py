"""Refresh the short handoff checkpoint without accumulating history."""
from pathlib import Path
import argparse, subprocess

ap=argparse.ArgumentParser()
ap.add_argument('checkpoint')
ap.add_argument('--next',required=True)
args=ap.parse_args()
repo=Path(__file__).resolve().parents[3]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
summary=f'''## 当前断点（2026-10-07，SC500原像素1080p30迁移）

- **目标与断点**：用户已批准实施1080p30分阶段迁移；{args.checkpoint}。阶段2仅RAW/GRAY，人工上板门槛通过后才集成完整EDGE。
- **分支/代码基线**：lj4747-contest-work；开始HEAD3be3967f2457622566fb20b7cef3aa5038e7d885；当前HEAD{head}。开始工作区干净，未覆盖其他改动。
- **改动文件**：详见本轮Git diff及开发实施/验收记录/20261007_原像素1080p30_轮次1.md；原Example、旧release及历史证据保留。
- **验证及证据**：207基线输入SHA核对一致；独立基线快照C:/Users/Li47/Desktop/aa/native_1080p30_baseline_20261007；旧bit SHA bb6a71443b74790c64ceec562236799dc5b9418c07f4634c141b4df2a8bb9d65。新增测试/TD/实物状态以本轮记录为准，不继承旧版通过结论。
- **未决事项**：本轮物理DDR写读/压力、输入1920×1080与30秒FPS、HDMI1080p30、RAW/GRAY各2分钟均待人工测试；DDR PLL/tCK/时序/刷新需与实际50MHz参考一致。CLASS_CALIBRATED=0，不启用T58。
- **下一条具体操作**：{args.next}。
- **运行中进程/设备**：用户TD GUI/bw/hwserver保留；助手进程以本轮记录/实际进程查询为准；未烧录或操作板卡。
- **提交/推送状态**：本轮变更尚未提交/推送；基线3be3967已在远端。仅续接个人分支，不pull/reset/强推。
'''
for path in (repo/'AGENTS.md',repo.parent/'AGENTS.md'):
    old=path.read_text(encoding='utf-8-sig').split('## 当前断点')[0]
    path.write_text(old+summary,encoding='utf-8')
(repo/'交接说明.md').write_text('# 当前接力说明\n\n'+summary+'\n历史冻结镜像、失败与复测证据保留在原release及验收记录。\n',encoding='utf-8')
print('Updated repository and outer handoff checkpoints')
