`timescale 1ns/1ps
module tb_compact_rgb;
reg clk=0,rst_n=0,vs=0,hs=0,de=0;always #5 clk=~clk;
reg [23:0] pixel=24'h123456;reg [23:0] expected0=0,expected1=0,expected2=0;
reg [2:0] vp=0,hp=0,dp=0;reg [10:0] qx[0:2];reg [9:0] qy[0:2];
reg [10:0] x=0;reg [9:0] y=0;
wire ov0,oh0,od0,ov1,oh1,od1;wire [23:0] rgb0,rgb1;
integer xx,yy,checks=0,active=0,plain=0;
generate for(genvar n=0;n<2;n=n+1)begin : configurations
 wire ov,oh,od;wire [23:0] rgb;
 compact_inspector_osd #(.WIDTH(1280),.HEIGHT(720),.ENABLE(n)) dut(
 .clk(clk),.rst_n(rst_n),.vs(vs),.hs(hs),.de(de),.rgb(pixel),.page(1'b0),
 .exposure(16'd1092),.gain(16'd40),.fps(16'd27),.width(16'd1920),.height(16'd1080),
 .wb_r(8'd100),.wb_b(8'd100),.roi_mean(8'd90),.roi_min(8'd20),.roi_max(8'd200),
 .wb_tune(1'b0),.wb_pending(1'b0),.roi_valid(1'b1),.cfg_done(1'b1),.view_mode(2'd0),.edge_count(13'd0),
 .lane_errors(16'd0),.format_errors(16'd0),.i2c_errors(16'd0),.gaps(16'd0),.overflow_frames(16'd0),.lost_frames(16'd0),.underflow_frames(16'd0),
 .frames(32'd42),.diagnostics(36'd0),.publish_diagnostic(27'd0),.objects(304'd0),.calibration_record(128'd0),.calibration_valid(1'b0),
 .local_wait_reason(4'd0),.live_record(256'd0),.frame_record(256'd0),.eligible(1'b0),
 .out_vs(ov),.out_hs(oh),.out_de(od),.out_rgb(rgb));
 if(n==0)begin assign ov0=ov;assign oh0=oh;assign od0=od;assign rgb0=rgb;end
 else begin assign ov1=ov;assign oh1=oh;assign od1=od;assign rgb1=rgb;end
end endgenerate
always @(negedge clk)pixel={pixel[22:0],pixel[23]^pixel[22]^pixel[21]^pixel[16]};
always @(posedge clk)begin
 expected0<=pixel;expected1<=expected0;expected2<=expected1;
 vp<={vp[1:0],vs};hp<={hp[1:0],hs};dp<={dp[1:0],de};
 qx[0]<=x;qx[1]<=qx[0];qx[2]<=qx[1];qy[0]<=y;qy[1]<=qy[0];qy[2]<=qy[1];
 #1;
 if(rst_n && checks>4)begin
  if({ov0,oh0,od0}!=={vp[2],hp[2],dp[2]} || {ov1,oh1,od1}!=={vp[2],hp[2],dp[2]})$fatal(1,"control latency");
  if(rgb0!==expected2)$fatal(1,"disabled OSD changed live RGB");
  if(od1)begin
   active=active+1;
   if(qx[2]<300 && qy[2]>=80 && qy[2]<624)begin
    plain=plain+1;if(rgb1!==expected2)$fatal(1,"enabled OSD changed unobstructed camera pixels");
   end
  end
 end
 checks=checks+1;
end
task tick;input integer count;integer i;begin for(i=0;i<count;i=i+1)@(negedge clk);end endtask
initial begin
 tick(10);rst_n=1;vs=1;tick(4);vs=0;tick(10);
 for(yy=0;yy<720;yy=yy+1)begin
  y=yy;hs=1;tick(2);hs=0;de=1;
  for(xx=0;xx<1280;xx=xx+1)begin x=xx;tick(1);end
  de=0;tick(10);
 end
 tick(10);
 if(active!=921600 || plain!=163200)$fatal(1,"coverage active=%d plain=%d",active,plain);
 $display("PASS compact RGB: %d clocks bypass, %d active pixels, %d unobstructed changing pixels, exact three-clock RGB/control",checks,active,plain);$finish;
end
initial begin #20000000;$fatal(1,"timeout");end
endmodule
