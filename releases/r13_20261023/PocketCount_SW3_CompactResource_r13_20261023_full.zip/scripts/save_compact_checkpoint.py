from pathlib import Path
import json,datetime,hashlib,re,shutil
r=Path(__file__).parent;c=r/'stage_B_r3';source=c/'source_snapshot';manifest=json.loads((c/'inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(q):
 b=q.read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
units=c/'units_r1/fpga/component_inspector';proof={}
for name in ['compact_ui','dual_page']:
 folder=units/'sim/modelsim_work'/name;s=read(folder/'compile.log');log=read(folder/'console.log');assert 'PASS ' in log and not re.search(r'\*\* (Fatal|Error):|Errors:\s*[1-9]',s+log)
 inputs={}
 for line in s.splitlines():
  if 'vlog ' in line and '-work' in line:
   for token in line.split():
    if token.endswith(('.v','.sv')):
     p=(units/'sim'/token).resolve();rel=p.relative_to(units).as_posix();assert sha(p)==manifest[rel],(name,rel);inputs[rel]=manifest[rel]
 proof[name]=dict(inputs=inputs,compile_sha256=sha(folder/'compile.log'),console_sha256=sha(folder/'console.log'))
capacity=json.loads((r/'stage_A_r0/unit_verification.json').read_text())
for n,record in capacity['tests'].items():
 for rel,digest in record['inputs'].items():assert manifest[rel]==digest,(n,rel)
base=Path('D:/CodexWork/classified_multithreshold_empty_20261022/candidate_r0/source_snapshot')
core=['frame_shape_search.v','empty_candidate_probe.v','inspection_region_config.v','classified_pocket_counter.v','classified_count_pipeline.v']
for name in core:
 rel='user_source/hdl_source/'+name;assert sha(base/rel)==manifest[rel]
for q in base.rglob('tb_*'):
 if q.is_file():rel=q.relative_to(base).as_posix();assert sha(q)==manifest[rel],rel
refs={}
e=c/'sealed_reference_scripts';e.mkdir(exist_ok=True)
for name in ['verify_compact_pixels.py','prepare_compact_ui.py']:
 shutil.copy2(r/name,e/name);refs[name]=sha(e/name)
result=dict(status='PASS_CAPACITY_AND_COMPACT_UI_EXACT_COMPILED_SHA_AND_3686400_INDEPENDENT_PIXELS',manifest_sha256=sha(c/'inputs.json'),unit_tests=proof,capacity_reused_actual_compiled_SHA=capacity['tests'],production_classifier_counter_unchanged=core,original_testbench_bytes_unchanged=True,reference_scripts=refs,pixel_report_sha256=sha(c/'independent_pixels/verification.json'),board_accuracy='NOT_ASSERTED')
(c/'supplement_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
s=json.loads((r/'current_status.json').read_text());s.update(status='R13_FROZEN_A_B_COMPLETE_FULL_REGRESSION_AND_SYN_RUNNING',updated=datetime.datetime.now().isoformat(),candidate='stage_B_r3',manifest_sha256=sha(c/'inputs.json'),source_count=len(manifest),running=dict(software=8732,physical=15576),next='Complete unchanged72 strict regression+10 native/RGB references. SYN measures combined resources, PHY only after all software and supplements gate, same SDC/seed2. No old-image overwrite or board operation.')
(r/'current_status.json').write_text(json.dumps(s,indent=2),encoding='utf-8')
text='''## 当前断点（2026-10-22，本聊天R13资源优化，A+B冻结/完整验证运行）

- 用户明确“两页精简，保留测试信息和主要位置”，有件/空穴/待复核中文、安路Logo、上下栏/ROI位置保留。按A缓存→B共享显示→C检测缓存；目标ERAM≤96/Slice<90%，尚待完整物理实测。
- 唯一实施D:/CodexWork/classified_resource_opt_20261022/development/fpga/component_inspector；来自R12 candidate_r0/458逐SHA。只读Git lj4747-contest-work/479a30b426d3a7edcde280d7bb202155fde4f310干净，开发胶囊无.git。另一原聊天R12D1诊断WIP不混入，旧镜像和现场失败保留。
- A缩AWB/RAW客户端地址为每行组数clog2、480组9位/512，3厂商包装器默认11/2048兼容；底层模型/数据宽/读写时序不改。stage_A_r0冻结462 manifest beb6c00c5ddb434a4134f16b4e667b5dec425fe4e69962933d922c64dde116ba，三尺寸实际厂商双DUT像素/控制/地址/断续/复位对照+manual_wb+fixed_wb通过。额外pixel_interface旧诊断与不可变R12均185行38460ns同失败，不在必测72，原日志保留、不改答案。
- A独立SYN exit0 ERAM89/108（较旧R12最终105差16）、DSP27/PLL5；Slice21678仅中间Gate102.18%非最终路由。#slice*解析器失败已修解析未重跑，stage_A_synth_r0保存原证据。
- B新增compact_inspector_osd/compact_template_rom/compact_cjk_rom/compact_ascii_rom；classified_dual_page_osd默认COMPACT_UI=0保留旧页层级，production top启1/.al列源。共享ASCII/七中文字/Logo/单数字转换；小类别标签替大卡，保留EXP/GAIN/FPS/MODE/WB、灰度/OBJ/CAL与完整D36/P、源帧/输运错误、总数/P/E/REVIEW子集、全部空号分页、C/FIRST和GAP编号存疑提示。检测/阈值/计数/ROI/SDC原字节不变。
- 最终暂冻stage_B_r3全部471，manifest243651b68a39160cfb81efe91b11836bcb32109750ecd29793530fca1bc98c65。新UI四完整720p栅格3686400像素与独立字面真值参考逐像素一致，帧中元数据变化/切页/清零/旧段守卫/三时钟通过；旧dual_page通过，实际编译SHA和旧72bench逐字节核对见supplement_verification.json。预览independent_pixels/actual_0.png、actual_1.png。r0保留Verilog保留字cell编译失败，r1改变量名后通过；r2补ASCII/空GAP/完整D36后源列表预检因shell引用失败未构建，r3只修列表。全部旧答案未改。
- 当前完整软件父8732（25项变化输入重跑，47项严格同实际编译/runtime SHA复用）；物理父15576独立SYN，门控等待72项+10 native/RGB及补充通过后才PHY，同原SDC/seed2，最终setup/hold非负/TNS0、46max/Ignored0、20Gray8ns/6邮箱/SW3完整扇出审计通过才交付。尚无新bit可烧。
- 下一条具体操作：查stage_B_r3/software_running.json、physical_r0/running.json及真实进程，勿重复启动。定位实际失败另冻，不放宽约束/答案；通过后新独立R13桌面bit/完整源证据/说明/SHA/回执与94依赖归档恢复校验。检测缓存C暂不动。
- 无子代理/板卡/JTAG/Flash/用户GUI/提交推送；automation/r12保持PAUSED，不创建/恢复跟进。原镜像/冻结/失败证据不覆盖。
'''
(r/'AGENTS.md').write_text(text,encoding='utf-8')
f=Path('C:/Users/Li47/Desktop/aa/AGENTS.md');old=f.read_text(encoding='utf-8-sig');tag='## 当前断点（2026-10-22，本聊天资源优化A验证与综合完成，B双页精简实施）';assert old.count(tag)==1
f.write_text(old[:old.index(tag)]+text,encoding='utf-8')
print(result['status'])
