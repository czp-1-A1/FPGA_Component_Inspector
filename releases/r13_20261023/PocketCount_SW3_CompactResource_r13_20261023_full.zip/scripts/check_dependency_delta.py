from pathlib import Path
import json
r=Path(__file__).parent
old=json.loads(Path('D:/CodexWork/classified_multithreshold_empty_20261022/physical_r0/fpga/component_inspector/portable_preparation.json').read_text())['inputs']
new=json.loads((r/'archived_prepared_r13/fpga/component_inspector/portable_preparation.json').read_text())['inputs']
print('Baseline',len(old),'current',len(new))
print('Added',sorted(set(new)-set(old)));print('Removed',sorted(set(old)-set(new)))
print('Changed entries', [q for q in old if q in new and old[q]!=new[q]])
