"""Preserve original actual runs. Restage reused byte-identical evidence in
new directories with the complete current reference-asset inventory. Neither
the frozen verifier, expectations, nor any previous run directory is edited.
"""
from pathlib import Path
import json,hashlib,shutil,os,importlib.util,subprocess,sys
r=Path(__file__).parent;c=r/'stage_B_r3';source=c/'source_snapshot';manifest=json.loads((c/'inputs.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
state=json.loads((c/'software_running.json').read_text());assert len(state['completed'])==25 and all(q['exit_code']==0 for q in state['completed'])
assert not (c/'software_runs_before_restage.json').exists()
shutil.copy2(c/'software_runs.json',c/'software_runs_before_restage.json');shutil.copy2(r/'full_software.err',c/'postprocess_runtime_inventory_failure_r0.log')
state.update(status='POSTPROCESSING_COMPLETE_ASSET_INVENTORY',actual_simulation_parent=state['pid'],pid=os.getpid())
def save():(c/'software_running.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
save();config=json.loads((c/'software_runs.json').read_text());prior=json.loads(Path('D:/CodexWork/classified_multithreshold_empty_20261022/candidate_r0/software_verification.json').read_text());mapping=[]
base=c/'restaged_reused_evidence';base.mkdir(exist_ok=False)
try:
 for origin in config['origins']:
  if 'reuse_reason' not in origin:continue
  old=Path(origin['project']);names=origin['tests'];assert len(names)==1;name=names[0];row=prior['tests'][name]
  assert Path(row['origin'])==old
  for group in ['inputs','runtime_inputs']:
   for rel,h in row[group].items():assert manifest[rel]==h and sha(old/rel)==h,(name,rel)
  p=base/name/'fpga/component_inspector';p.mkdir(parents=True)
  for rel,h in manifest.items():
   q=p/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/rel,q);assert sha(q)==h
  oldlogs=old/'sim/modelsim_work'/name;dest=p/'sim/modelsim_work'/name;dest.mkdir(parents=True)
  for filename in ['compile.log','console.log','transcript.log']:
   if(oldlogs/filename).exists():shutil.copy2(oldlogs/filename,dest/filename);assert sha(oldlogs/filename)==sha(dest/filename)
  assert sha(dest/'compile.log')==row['compile_sha256'] and sha(dest/'console.log')==row['console_sha256']
  vendor=old/'sim/modelsim_vendor_compile.log'
  if vendor.exists():shutil.copy2(vendor,p/'sim'/vendor.name)
  # Keep native artifacts from the actual run, never regenerate answers.
  for q in (old/'sim').iterdir():
   if q.is_file() and q.suffix.lower() in {'.pgm','.ppm'}:shutil.copy2(q,p/'sim'/q.name);assert sha(q)==sha(p/'sim'/q.name)
  added=[rel for rel in manifest if rel.startswith('sim/') and Path(rel).suffix.lower() in {'.hex','.mif','.dat'} and not (old/rel).exists()]
  # Newly emitted compact-font/template HEX are documentation of literal RTL
  # ROMs. No reused input references compact_assets or reads those files.
  assert all(rel.startswith('sim/compact_assets/') for rel in added)
  for rel in row['inputs']:
   assert b'compact_assets' not in (old/rel).read_bytes(),(name,rel)
  mapping.append(dict(test=name,actual_original_project=str(old),evidence_copy_project=str(p),compile_sha256=row['compile_sha256'],console_sha256=row['console_sha256'],actual_compiled_inputs=row['inputs'],actual_prior_reference_inventory=row['runtime_inputs'],new_unused_inventory_files=added,not_a_new_simulation=True))
  origin.update(project=str(p),actual_original_project=str(old),provenance='Copied exact original successful compile/console/artifacts. Compiled/runtime inputs byte identical. New compact HEX inventory is literal-ROM documentation, unused by this actual run. Not a new simulation.')
 (c/'evidence_restage_provenance.json').write_text(json.dumps(dict(status='REUSED_ACTUAL_INPUTS_AND_LOGS_BYTE_IDENTICAL_COMPLETE_INVENTORY',source_manifest_sha256=sha(c/'inputs.json'),tests=mapping),indent=2),encoding='utf-8')
 (c/'software_runs.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
 spec=importlib.util.spec_from_file_location('verifier',source/'tools/verify_result_recorder_software.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 m.verify(c/'inputs.json',source,c/'software_runs.json',c/'software_verification.json')
 print('PASS72 strict unmodified verifier; exact original provenance preserved',flush=True)
 origins=config['origins']
 for n,tool in [('recovery_raw_motion','check_recovery_raw_reference.py'),('ordered_raw_motion','check_ordered_raw_reference.py'),('tail_recovery_raw','check_tail_recovery_raw_reference.py'),('motion_recovery_raw','check_motion_recovery_raw_reference.py'),('result_recorder_raw_motion','check_result_recorder_raw_reference.py'),('classified_raw_motion','check_classified_raw_reference.py')]:
  p=Path(next(o['project'] for o in origins if n in o['tests']));subprocess.run([sys.executable,str(source/'tools'/tool),str(p/'sim'),'--output',str(c/(n+'_independent_reference.json'))],check=True)
 for n in ['start_entry_raw','speed_raw']:
  p=Path(next(o['project'] for o in origins if n in o['tests']));subprocess.run([sys.executable,str(source/'tools/check_start_speed_raw_reference.py'),str(p/'sim'),'--test',n,'--output',str(c/(n+'_independent_reference.json'))],check=True)
 subprocess.run([sys.executable,str(r/'compare_original_ui_native.py')],check=True)
 subprocess.run([sys.executable,str(r/'verify_new_native_protocol.py'),str(c)],check=True)
 for n,tool,args in [('local_raw_motion','check_local_raw_reference.py',['--source',str(source),'--sim']),('dual_raw_motion','check_dual_raw_reference.py',[])]:
  p=Path(next(o['project'] for o in origins if n in o['tests']))
  cmd=[sys.executable,str(source/'tools'/tool),*args,str(p/'sim')]
  if n=='dual_raw_motion':cmd+=['--test',n]
  subprocess.run([*cmd,'--output',str(c/(n+'_independent_reference.json'))],check=True)
 p=Path(next(o['project'] for o in origins if 'dual_motion' in o['tests']))
 subprocess.run([sys.executable,str(source/'tools/check_dual_rgb_reference.py'),str(p/'sim'),'--output',str(c/'dual_motion_independent_reference.json')],check=True)
 state.update(status='PASS72_AND_TEN_NATIVE_PLUS_RGB_REFERENCE',actual_runs=25,identical_reused=47);save();print(state['status'],flush=True)
except Exception:
 state['status']='FAIL';save();raise
