from pathlib import Path
import json,hashlib
r=Path(__file__).parent;old=Path('D:/CodexWork/classified_multithreshold_empty_20261022');c=r/'stage_B_r3'
assert json.loads((c/'independent_pixels/verification.json').read_text())['status']=='PASS'
(c/'required_tests.json').write_bytes((old/'candidate_r0/required_tests.json').read_bytes())
s=(old/'run_frozen_software.py').read_text()
s=s.replace("root=Path(__file__).parent;c=root/'candidate_r0'","root=Path(__file__).parent;c=root/'stage_B_r3'",1)
s=s.replace("D:/CodexWork/classified_local_recovery_20261022/candidate_r1/software_verification.json",str(old/'candidate_r0/software_verification.json').replace('\\','/'),1)
# Keep all original72 contracts, their expectation bytes, strict input verifier,
# ten actual-pixel references and RGB reference. Changed module clients rerun.
(r/'run_full_software.py').write_text(s,encoding='utf-8')
s=(old/'compare_original_ui_native.py').read_text().replace("root=Path(__file__).parent;c=root/'candidate_r0'","root=Path(__file__).parent;c=root/'stage_B_r3'",1)
(r/'compare_original_ui_native.py').write_text(s,encoding='utf-8')
(r/'verify_new_native_protocol.py').write_bytes((old/'verify_new_native_protocol.py').read_bytes())
print('Prepared unchanged72 contracts plus independent UI and capacity supplements')
