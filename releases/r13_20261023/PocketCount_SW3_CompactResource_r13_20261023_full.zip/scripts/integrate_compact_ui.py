from pathlib import Path
import hashlib,json
r=Path(__file__).parent;p=r/'development/fpga/component_inspector';h=p/'user_source/hdl_source'
f=h/'classified_dual_page_osd.v';s=f.read_bytes();assert b'COMPACT_UI' not in s
s=s.replace(b'parameter CLASSIFIED_COUNT=0,',b'parameter COMPACT_UI=0,CLASSIFIED_COUNT=0,',1)
s=s.replace(b'generate if(CLASSIFIED_COUNT)begin : counting_page',b'generate if(CLASSIFIED_COUNT && !COMPACT_UI)begin : counting_page',1)
old=b'assign out_vs=lv;assign out_hs=lh;assign out_de=ld;\r\nassign out_rgb=page_s && !count_logo ? count_rgb : legacy_rgb;'
assert old in s
new='''generate if(COMPACT_UI)begin : compact_page
 compact_inspector_osd #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.DIAG_BITS(DIAG_BITS),.ENABLE(ENABLE)) render(
 .clk(clk),.rst_n(rst_n),.vs(vs),.hs(hs),.de(de),.rgb(rgb),.page(page_s),
 .exposure(exposure),.gain(gain),.fps(fps),.width(width),.height(height),
 .wb_r(wb_r),.wb_b(wb_b),.roi_mean(roi_mean),.roi_min(roi_min),.roi_max(roi_max),
 .wb_tune(wb_tune),.wb_pending(wb_pending),.roi_valid(roi_valid),.cfg_done(cfg_done),
 .view_mode(view_mode),.edge_count(edge_count),.lane_errors(lane_errors),.format_errors(format_errors),
 .i2c_errors(i2c_errors),.gaps(gaps),.overflow_frames(overflow_frames),.lost_frames(lost_frames),.underflow_frames(underflow_frames),
 .frames(frames),.diagnostics(diagnostics),.publish_diagnostic(publish_diagnostic),.objects(frame_objects),
 .calibration_record(calibration_record),.calibration_valid(calibration_valid),.local_wait_reason(local_wait_reason),
 .live_record(count_live_record),.frame_record(count_frame_record),.eligible(count_eligible),
 .out_vs(out_vs),.out_hs(out_hs),.out_de(out_de),.out_rgb(out_rgb));
end else begin : unchanged_pages
 assign out_vs=lv;assign out_hs=lh;assign out_de=ld;
 assign out_rgb=page_s && !count_logo ? count_rgb : legacy_rgb;
end endgenerate'''
f.write_bytes(s.replace(old,new.replace('\n','\r\n').encode(),1))
f=h/'design_top_wrapper.v';s=f.read_bytes();tag=b'classified_dual_page_osd #(.CLASSIFIED_COUNT';assert s.count(tag)==1
f.write_bytes(s.replace(tag,b'classified_dual_page_osd #(.COMPACT_UI(CLASSIFIED_COUNT),.CLASSIFIED_COUNT',1))
f=p/'td_project/camera_to_dsi_display.al';s=f.read_bytes();tag=b'            <File Path="../user_source/hdl_source/classified_count_renderer.v">';assert tag in s
names=['compact_inspector_osd','compact_template_rom','compact_cjk_rom']
new=''.join(f'            <File Path="../user_source/hdl_source/{name}.v"><FileInfo><Attr Name="UsedInSyn" Val="true"/><Attr Name="UsedInP&amp;R" Val="true"/><Attr Name="BelongTo" Val="design_1"/><Attr Name="CompileOrder" Val="231"/></FileInfo></File>\r\n' for name in names).encode()
f.write_bytes(s.replace(tag,new+tag,1))
(r/'stage_B_scope.json').write_text(json.dumps({'production_changes':['classified_dual_page_osd: COMPACT_UI default0 retains original test hierarchy and legacy pages','design_top_wrapper: production compact branch enabled','new shared renderer, seven CJK glyphs and token ROM, .al list'],'algorithm_counter_constraints_unchanged':True,'new_layout_reference':'sim/compact_assets/layout.json','old_72_testbench_bytes_unchanged':True},indent=2),encoding='utf-8')
print('Integrated default-off compact UI; production enables it, legacy hierarchy intact')
