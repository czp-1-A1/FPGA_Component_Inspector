from pathlib import Path
import re,json,hashlib
root=Path(__file__).parent;c=root/'stage_B_r3';rows={};hashes={};proof={}
for n in ['classified_raw_motion','result_recorder_raw_motion']:
 sim=Path(json.loads((c/'software_verification.json').read_text(encoding='utf-8'))['tests'][n]['origin'])/'sim';p=sim/'modelsim_work'/n/'console.log';b=p.read_bytes();log=b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
 assert 'PASS ' in log and '** Fatal:' not in log
 rows[n]=re.findall(r'REF region cadence frame=(\d+) objects=([0-9a-fA-F]+)',log);assert [int(a) for a,_ in rows[n]]==list(range(1,8))
 hashes[n]=[hashlib.sha256((sim/f'region_cadence_{i}.pgm').read_bytes()).hexdigest() for i in range(1,8)]
 proof[n]={'console_sha256':hashlib.sha256(b).hexdigest(),'original_two_result_packets':rows[n],'actual_post_pixel_sha256':hashes[n]}
assert rows['classified_raw_motion']==rows['result_recorder_raw_motion']
assert hashes['classified_raw_motion']==hashes['result_recorder_raw_motion']
(c/'native_original_ui_identity.json').write_text(json.dumps({'status':'PASS_SEVEN_NATIVE_SOURCE_FRAMES_ORIGINAL_TWO_RECORDS_AND_ACTUAL_PIXELS_IDENTICAL','scope':'Original classifier/COUNT_CANDIDATES0 vs recorder-side COUNT_CANDIDATES1 native RAW runs, same source stimuli. All original2 fields and postISP pixels identical. Supplement to69 immutableR7 PPC4 comparison checks; not board image accuracy.','proof':proof},indent=2),encoding='utf-8')
print('PASS_7_NATIVE_ORIGINAL_UI_PAIR_AND_POST_PIXELS_IDENTITY')
