"""Independent sequential named-field decode of R10 entry/speed native tuples."""
from pathlib import Path
import hashlib,json,re,sys
FIELDS=[('source',32),('generation',16),('state',3),('reason',4),('direction_valid',1),('direction_right',1),('region',1),('total',9),('present',9),('empty',9),('review',9),('object_ids',36),('empty_ids',72),('last_id',9),('last_kind',2),('last_reason',4),('page',6),('valid',1),('visible_run',16),('first_fault',16)]
assert sum(w for _,w in FIELDS)==256

def verify(candidate):
    sys.path.insert(0,str(candidate/'source_snapshot/tools'))
    from check_motion_recovery_raw_reference import record
    sw=json.loads((candidate/'software_verification.json').read_text(encoding='utf-8'));proof={}
    for name in ['start_entry_raw','speed_raw','dual_raw_motion']:
        leading=name=='start_entry_raw';frames=22 if leading else 11
        path=Path(sw['tests'][name]['origin'])/'sim/modelsim_work'/name/'console.log'
        b=path.read_bytes();s=b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
        assert 'PASS '+name.replace('_',' ')+':' in s and '** Fatal:' not in s
        packets={int(n):int(v,16) for n,v in re.findall(r'SPEED_CANDIDATES source=(\d+) data=([0-9a-fA-F]+)',s)}
        rows=re.findall(r'SPEED_NATIVE_RESULT source=(\d+) record=([0-9a-fA-F]+)',s)
        assert [int(n) for n,_ in rows]==list(range(1,frames+1))
        crossings=[13,16,18,20] if leading else [5,7,8,9]
        kinds=[3,2,2,2] if leading else [2,3,3,2];checked=[]
        for fs,value in rows:
            frame=int(fs);v=int(value,16);d={};offset=0
            for name_field,width in FIELDS:d[name_field]=v>>offset&((1<<width)-1);offset+=width
            count=sum(frame>=f for f in crossings);empty=sum(frame>=f and k==3 for f,k in zip(crossings,kinds))
            assert d['source']==frame and d['valid']==1 and d['visible_run']==1 and d['region']==0
            assert d['state']==(1 if frame<4 else 2) and d['reason']==(1 if frame<4 else 0),(name,frame,d)
            assert d['total']==count and d['empty']==empty and d['present']==count-empty
            assert d['review']<=d['present'] and d['first_fault']==0
            assert d['last_id']==count and d['last_kind']==(kinds[count-1] if count else 0)
            expected_empty=[i+1 for i,(f,k) in enumerate(zip(crossings,kinds)) if frame>=f and k==3]
            ids=[d['empty_ids']>>(i*9)&511 for i in range(8)]
            assert ids==expected_empty+[0]*(8-len(expected_empty))
            display=[d['object_ids']>>(i*9)&511 for i in range(4)];assert display[2:]==[0,0]
            shift=(frame-1)*20 if leading else ((frame-1)*20 if frame<=3 else 64 if frame==4 else 92 if frame==5 else 124+(frame-6)*32)
            first=(402 if leading else 558)+shift;bindings=[]
            for slot in range(2):
                ob=record(packets[frame]>>(slot*76)&((1<<76)-1))
                if not ob['valid'] or ob['kind']<2:assert display[slot]==0;continue
                cx=(ob['x0']+ob['x1'])/2;index=round((cx-first)/44);assert index in (0,-1,-2,-3)
                number=1-index;expected=number if frame>=crossings[number-1] else 0
                assert display[slot]==expected,(name,frame,slot,index,display,expected)
                assert ob['kind']==kinds[number-1]
                bindings.append({'slot':slot,'physical_index':index,'actual_pixel_cx':cx,'display_id':display[slot]})
            checked.append({'frame':frame,'decoded':d,'pixel_id_bindings':bindings})
        proof[name]={'console_sha256':hashlib.sha256(b).hexdigest(),'frames':checked}
    result={'status':'PASS_NAMED_NEW_ENTRY_SPEED_PROTOCOL_44_FRAMES_AND_ORIGINAL_PIXEL_IDS','source_manifest_sha256':hashlib.sha256((candidate/'inputs.json').read_bytes()).hexdigest(),'schema':FIELDS,'tests':proof,'board_accuracy':'NOT_ASSERTED'}
    (candidate/'new_native_protocol_identity.json').write_text(json.dumps(result,indent=2),encoding='utf-8');return result

if __name__=='__main__':print(verify(Path(sys.argv[1]))['status'])
