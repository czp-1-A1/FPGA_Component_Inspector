from pathlib import Path
import importlib.util,subprocess,json,os,time,hashlib,shutil,sys
r=Path(__file__).parent;c=r/(sys.argv[1] if len(sys.argv)>1 else 'stage_B_r0');work=c/'units_r1/fpga/component_inspector'
spec=importlib.util.spec_from_file_location('prepare',Path('D:/CodexWork/classified_multithreshold_empty_20261022/prepare_portable_project.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
if not work.exists():m.prepare(c/'source_snapshot',c/'inputs.json',work,Path('D:/td6.2.1'))
else:
 for rel,digest in json.loads((c/'inputs.json').read_text()).items():
  if rel!='td_project/camera_to_dsi_display.al':assert hashlib.sha256((work/rel).read_bytes()).hexdigest()==digest,rel
 if (c/'compact_ui_runner.log').exists():shutil.copy2(c/'compact_ui_runner.log',c/'tool_execution_policy_failure_r0.log')
state={'status':'RUNNING','pid':os.getpid(),'tests':['compact_ui','dual_page'],'hardware_operation':False}
(c/'units_running.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
results=[]
for test in state['tests']:
 t=time.time()
 with (c/(test+'_runner.log')).open('wb') as log:
  code=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-Command',f"& './sim/run_modelsim.ps1' -ModelSimBin 'D:/modeltech64_10.5/win64' -TdSimRoot 'D:/td6.2.1/sim_release' -OnlyTests {test}"],cwd=work,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append(dict(test=test,exit_code=code,seconds=time.time()-t));state['results']=results
 (c/'units_running.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
 if code:state['status']='FAIL_RETAINED';break
else:state['status']='PASS_RUNTIME_INDEPENDENT_REFERENCE_PENDING'
(c/'units_running.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
print(json.dumps(state),flush=True)
