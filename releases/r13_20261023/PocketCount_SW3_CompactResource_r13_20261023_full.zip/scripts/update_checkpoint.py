from pathlib import Path
import json,re,datetime
r=Path(__file__).parent
s=r/'stage_A_synth_r0/running.json'
state=json.loads(s.read_text())
log=(r/'stage_A_synth_r0/SYN.log').read_text(encoding='utf-8-sig',errors='replace')
area=(r/'stage_A_synth_r0/fpga/component_inspector/td_project/camera_to_dsi_display_Runs/syn_1/camera_to_dsi_display_gate.area').read_text(encoding='utf-8-sig')
err=(r/'stage_A_synth_runner.err').read_text(encoding='utf-8-sig')
assert "line 44" in err and "TypeError: 'NoneType'" in err
# The original runner can reach line44 only after subprocess.returncode == 0.
state['exit_code']=0
state.update(status='PASS_SYN_ONLY_NOT_ROUTED',resources={k:int(re.search(r'^#'+k+r'\*?\s+(\d+)',area,re.M)[1]) for k in ['slice','eram','dsp','pll']},postprocess_repair='Original parser did not accept #slice*. Original SYN exit0 and area preserved; no rebuild.',completed=datetime.datetime.now().isoformat())
s.write_text(json.dumps(state,indent=2),encoding='utf-8')
status=json.loads((r/'current_status.json').read_text())
status.update(status='STAGE_A_UNITS_AND_SYN_PASS_B_COMPACT_UI_IMPLEMENTING',updated=datetime.datetime.now().isoformat(),running={},stage_A_manifest_sha256='beb6c00c5ddb434a4134f16b4e667b5dec425fe4e69962933d922c64dde116ba',stage_A_resources_SYN_ONLY=state['resources'],next='B shared compact UI, Chinese classes/Logo/test fields/ROI positions. Freeze new layout and validate. Classifier/counter/SDC unchanged; full regression and routed audit still required.')
(r/'current_status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
text='''## 当前断点（2026-10-22，本聊天资源优化A验证与综合完成，B双页精简实施）

- 用户已明确“两页精简，保留测试信息和主要位置”；有件/空穴/待复核中文、安路Logo、上下栏/ROI位置保留，按A缓存→B共享显示→C检测缓存顺序。ERAM≤96/Slice<90%仍是目标。
- 唯一实施D:/CodexWork/classified_resource_opt_20261022/development/fpga/component_inspector，来自R12 candidate_r0全部458逐SHA；只读Git lj4747-contest-work/479a30b426d3a7edcde280d7bb202155fde4f310干净。原聊天idle，另一R12D1诊断WIP不混入。
- A改6RTL缩AWB/RAW客户端地址到每行组数clog2，1920/PPC4=480组、9位/512；3厂商包装器默认11/2048兼容，底层厂商模型和读写时序不变。stage_A_r0冻结462，manifest beb6c00c5ddb434a4134f16b4e667b5dec425fe4e69962933d922c64dde116ba。
- 实际原厂ModelSim：新三尺寸双DUT逐有效像素/控制/地址/断续/复位对照、manual_wb、fixed_wb三bench通过，实际编译输入逐SHA验证。额外pixel_interface诊断与不可变R12均同185行/38460ns失败（旧用例要求已修复的残行重播行为），不在原72必测内；两次失败原日志保留，不改答案。
- A独立SYN exit0，ERAM89/108（旧R12最终105，仅容量实测差16），DSP27/PLL5；Slice21678/21216为Optimize-Gate中间估算102.18%，不能当最终路由利用率/通过。输出解析器因#slice*失败已修解析，不重跑；证据stage_A_synth_r0。无A PHY/bit，不声称最终目标通过。
- 下一条：B共享紧凑渲染/单ASCII与少量中文/单数字转换，提前冻结布局参考，新UI像素与元数据绑定验证；旧72bench与算法答案原字节保留。合并冻结后完整软件/真实RAW/独立参考、同SDC全路由与约束通过才桌面新bit/完整包/说明/SHA。
- A父32196已结束，无助手在跑TD/ModelSim、无子代理/板卡/JTAG/Flash/用户GUI、提交推送；automation/r12保持PAUSED。旧镜像、失败证据保留。
'''
(r/'AGENTS.md').write_text(text,encoding='utf-8')
p=Path('C:/Users/Li47/Desktop/aa/AGENTS.md');old=p.read_text(encoding='utf-8-sig');tag='## 当前断点（2026-10-22，本聊天资源优化开始，A缓存缩深未验证）'
assert old.count(tag)==1
p.write_text(old[:old.index(tag)]+text,encoding='utf-8')
print(json.dumps(state,indent=2))
