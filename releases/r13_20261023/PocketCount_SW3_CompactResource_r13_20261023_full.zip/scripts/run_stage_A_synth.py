from pathlib import Path
import json,re,hashlib,importlib.util,subprocess,os,time,datetime
root=Path(__file__).parent;c=root/'stage_A_r0';source=c/'source_snapshot'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
manifest=json.loads(read(c/'inputs.json'))
for r,h in manifest.items():assert sha(source/r)==h,r
project=c/'units/fpga/component_inspector';proof={}
for name in ['line_ram_equivalence','manual_wb','fixed_wb']:
 folder=project/'sim/modelsim_work'/name;compile_log=read(folder/'compile.log');console=read(folder/'console.log')
 assert 'PASS ' in console and not re.search(r'\*\* (Fatal|Error):|Errors:\s*[1-9]',compile_log+console),name
 inputs={}
 for line in compile_log.splitlines():
  if 'vlog ' in line and '-work' in line:
   for token in line.split():
    if token.endswith(('.v','.sv')):
     p=(project/'sim'/token).resolve();rel=p.relative_to(project).as_posix();assert sha(p)==manifest[rel],(name,rel);inputs[rel]=manifest[rel]
 assert inputs
 proof[name]=dict(inputs=inputs,console_sha256=sha(folder/'console.log'),compile_sha256=sha(folder/'compile.log'),pass_lines=[x for x in console.splitlines() if 'PASS ' in x])
legacy={}
for name,p in [('current',project),('baseline',root/'pixel_baseline_r0/fpga/component_inspector')]:
 log=p/'sim/modelsim_work/pixel_interface/console.log';s=read(log)
 assert '** Fatal: expected incomplete line to expose fixed-width replay behavior' in s and 'Time: 38460 ns' in s
 assert sha(p/'sim/tb_pixel_interface.v')==manifest['sim/tb_pixel_interface.v']
 legacy[name]=dict(console_sha256=sha(log),failure='Legacy diagnostic expects repaired incomplete-line replay bug; unchanged R12 fails at same source line185/time38460ns; not in immutable required72')
base=json.loads(read(root/'baseline_inputs.json'))
for name,rel in [('signal_delay','user_source/hdl_source/signal_delay.v'),('line_buffer_demosaic','user_source/hdl_source/isp/demosaic_4x_2_0/line_buffer_demosaic.v'),('zhenghe','user_source/hdl_source/isp/demosaic_4x_2_0/zhenghe.v')]:
 ref=source/f'sim/reference/resource_R12_{name}.v';original=Path('D:/CodexWork/classified_multithreshold_empty_20261022/candidate_r0/source_snapshot')/rel
 assert sha(original)==base[rel]
 assert re.sub(rb'\bmodule\s+resource_R12_'+name.encode()+rb'\b',b'module '+name.encode(),ref.read_bytes(),count=1)==original.read_bytes()
(c/'unit_verification.json').write_text(json.dumps(dict(status='PASS_THREE_CAPACITY_WB_CONTRACTS_EXACT_COMPILED_SHA',manifest_sha256=sha(c/'inputs.json'),tests=proof,legacy_failure_preserved=legacy),indent=2),encoding='utf-8')
work=root/'stage_A_synth_r0/fpga/component_inspector'
helper=Path('D:/CodexWork/classified_multithreshold_empty_20261022/prepare_portable_project.py')
spec=importlib.util.spec_from_file_location('prepare',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.prepare(source,c/'inputs.json',work,Path('D:/td6.2.1'))
state=dict(status='RUNNING',phase='SYN_ONLY',pid=os.getpid(),source_manifest_sha256=sha(c/'inputs.json'),hardware_operation=False)
out=root/'stage_A_synth_r0';(out/'running.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
start=time.time()
with (out/'SYN.log').open('wb') as log:code=subprocess.run(['D:/td6.2.1/bin/td_commands_prompt.exe','build.tcl'],cwd=work/'td_project/camera_to_dsi_display_Runs/syn_1',stdout=log,stderr=subprocess.STDOUT).returncode
state.update(exit_code=code,seconds=time.time()-start)
if code:state['status']='FAIL_SYN';(out/'running.json').write_text(json.dumps(state,indent=2),encoding='utf-8');raise SystemExit(1)
area=read(work/'td_project/camera_to_dsi_display_Runs/syn_1/camera_to_dsi_display_gate.area')
state.update(status='PASS_SYN_ONLY_NOT_ROUTED',resources={k:int(re.search(r'^#'+k+r'\s+(\d+)',area,re.M)[1]) for k in ['slice','eram','dsp','pll']},completed=datetime.datetime.now().isoformat())
(out/'running.json').write_text(json.dumps(state,indent=2),encoding='utf-8');print(json.dumps(state),flush=True)
