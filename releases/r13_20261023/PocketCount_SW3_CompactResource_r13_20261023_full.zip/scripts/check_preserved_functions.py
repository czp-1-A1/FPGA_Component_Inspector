"""Read-only, before-release compatibility inventory. This does not replace
the ongoing native RAW runs or routed timing/constraint gate."""
from pathlib import Path
import json,hashlib,datetime
r=Path(__file__).parent;c=r/'stage_B_r3';src=c/'source_snapshot';base=Path('D:/CodexWork/classified_multithreshold_empty_20261022/candidate_r0')
old=json.loads((base/'inputs.json').read_text());new=json.loads((c/'inputs.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
allowed=set(json.loads((r/'stage_A_changes.json').read_text()).keys())
# Document observed production edits; no wildcard exception to the algorithm.
changed=[rel for rel in old if new.get(rel)!=old[rel]]
expected={'user_source/hdl_source/signal_delay.v','user_source/hdl_source/isp/demosaic_4x_2_0/line_buffer_demosaic.v','user_source/hdl_source/isp/demosaic_4x_2_0/zhenghe.v','user_source/hdl_source/isp/demosaic_4x_2_0/blk_mem_gen_demosaic/blk_mem_gen_demosaic.v','user_source/hdl_source/isp/demosaic_4x_2_0/blk_mem_gen_zhenghe/blk_mem_gen_zhenghe.v','user_source/ip_source/blk_mem_gen_awb_delay_signal/blk_mem_gen_awb_delay_signal.v','user_source/hdl_source/classified_dual_page_osd.v','user_source/hdl_source/design_top_wrapper.v','td_project/camera_to_dsi_display.al','sim/run_modelsim.ps1'}
assert set(changed)==expected,(set(changed)-expected,expected-set(changed))
for rel,h in new.items():assert sha(src/rel)==h,rel
assert all(new[rel]==h for rel,h in old.items() if rel.startswith('sim/tb_') or rel.endswith(('.sdc','.adc')))
unchanged=['frame_shape_search.v','inspection_region_config.v','empty_candidate_probe.v','classified_pocket_counter.v','classified_count_pipeline.v','pocket_run_controls.v','awb.v','rgb_resize_2_3.v','roi_frame_guard.v','scaled_frame_guard.v','frame_process_bridge.v','video_in.v','video_out.v','status_cdc.v','native_720p60_vtc.v','hdmi_phy_warpper.v']
preserved={}
for name in unchanged:
 matches=[rel for rel in old if Path(rel).name==name];assert matches,name
 for rel in matches:assert new[rel]==old[rel];preserved[rel]=new[rel]
prior=json.loads((base/'software_verification.json').read_text());plan=json.loads((c/'rerun_plan.json').read_text());reused=[]
for reuse in plan['identical_reused']:
 for name in reuse['tests']:
  row=prior['tests'][name];origin=Path(row['origin'])
  for group in ['inputs','runtime_inputs']:
   for rel,h in row[group].items():assert new[rel]==h and sha(origin/rel)==h,(name,rel)
  logs=origin/'sim/modelsim_work'/name
  assert sha(logs/'compile.log')==row['compile_sha256'] and sha(logs/'console.log')==row['console_sha256'];reused.append(name)
result=dict(status='PASS_READONLY_SCOPE_AND_PRESERVED_FUNCTION_INPUTS_FULL_NATIVE_PHY_STILL_REQUIRED',manifest_sha256=sha(c/'inputs.json'),original_changed_inputs=changed,unchanged_core=preserved,all_original_testbench_and_constraints_unchanged=True,actual_reuse_proofs_rechecked=reused,board_test='PENDING',created=datetime.datetime.now().isoformat())
(r/'preserved_function_preflight.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(result['status'],len(reused))
