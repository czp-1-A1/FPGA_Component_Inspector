from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).parent
old=json.loads(Path('D:/CodexWork/classified_multithreshold_empty_20261022/physical_r0/fpga/component_inspector/portable_preparation.json').read_text())
new=json.loads((r/'archived_prepared_r13/fpga/component_inspector/portable_preparation.json').read_text())
added={f'user_source/hdl_source/{n}.v' for n in ['compact_ascii_rom','compact_cjk_rom','compact_inspector_osd','compact_template_rom']}
assert len(old['inputs'])==94 and set(new['inputs'])==set(old['inputs'])|added and len(new['inputs'])==98
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=dict(status='PASS_EXACT_BASELINE94_PLUS_FOUR_NEW_DISPLAY_MODULES_NO_REMOVAL',baseline_inputs=old['inputs'],added=sorted(added),expected_dependencies=sorted(set(old['inputs'])|added),actual_count=98,source_manifest_sha256='243651b68a39160cfb81efe91b11836bcb32109750ecd29793530fca1bc98c65')
(r/'project_dependency_delta.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
shutil.copy2(r/'delivery_receipt.json',r/'delivery_receipt_r0_pending.json')
guide=(r/'r13_guide_template.md').read_text(encoding='utf-8').replace('94个项目/IP依赖','98个项目/IP依赖（原94项全部保留，增加4个显示模块）')
guide=guide.replace('是否达到ERAM≤96/Slice<90%的目标由release_verification.json明确记录；综合中间估计不充作最终值。','ERAM≤96的目标已达成；Slice为92.89%，低于90%的目标本轮未达成。原算法与计数逻辑保持，先用于实物对照；综合中间估计不充作最终值。')
(r/'r13_guide_template_r1.md').write_text(guide,encoding='utf-8')
s=(r/'package_r13.py').read_text(encoding='utf-8')
s=s.replace("NAME='PocketCount_SW3_CompactResource_r13_20261022'","NAME='PocketCount_SW3_CompactResource_r13_20261023'",1).replace("R/'r13_guide_template.md'","R/'r13_guide_template_r1.md'",1)
s=s.replace("copy(R/'preserved_function_preflight.json',release/'validation/preserved_function_preflight.json')","copy(R/'preserved_function_preflight.json',release/'validation/preserved_function_preflight.json')\n copy(R/'project_dependency_delta.json',release/'validation/project_dependency_delta.json')")
(r/'package_r13_r1.py').write_text(s,encoding='utf-8')
s=(r/'verify_archive_r13.py').read_text(encoding='utf-8').replace("NAME='PocketCount_SW3_CompactResource_r13_20261022'","NAME='PocketCount_SW3_CompactResource_r13_20261023'",1)
s=s.replace("R/'archived_replay_r13'","R/'archived_replay_r13_r1'",1).replace("R/'archived_prepared_r13/fpga/component_inspector'","R/'archived_prepared_r13_r1/fpga/component_inspector'",1)
tag="assert len(prepared['inputs'])==94";assert tag in s
s=s.replace(tag,"proof=json.loads((R/'project_dependency_delta.json').read_text(encoding='utf-8'));assert set(prepared['inputs'])==set(proof['expected_dependencies']) and len(prepared['inputs'])==98",1)
s=s.replace('FRESH94_PROJECT','FRESH98_PROJECT').replace('project_ip_dependencies=94','project_ip_dependencies=98')
(r/'verify_archive_r13_r1.py').write_text(s,encoding='utf-8')
f=r/'开发实施/验收记录/20261023_R13_归档依赖闭包_轮次3.md'
f.write_text('''# R13 独立归档复原的项目依赖清单修正

原冻结471、bit SHA2350b5985afa679df3d8bfd1a5fa2aba9f355468f284704d10dd46beeda402a7、全部软件与最终路由审计保持不变。最初20261022命名交付的所有载荷/源码/日志/参考SHA均通过；最后新目录prepare已成功，仅独立校验脚本硬编码94而失败。

已按原R12真实准备清单94项逐键核对：所有旧项均存在，新增恰为compact_ascii_rom.v、compact_cjk_rom.v、compact_inspector_osd.v、compact_template_rom.v共4项，当前应为98。project_dependency_delta.json固定完整预期集合，复原校验改为集合完全一致且98项，不是任意放宽数量或忽略缺项。新增源码仍逐SHA与冻结471及已构建源核对。

首次失败及包保留，不覆盖任何旧镜像/包。最终独立交付改为20261023文件名，同一bit内容不重编，修正烧录说明及复原校验脚本后再整体封包、逐载荷SHA/CRC、独立新目录复原确认。外部最终交付回执是是否完成的唯一依据。

实物未测，Slice最终92.89%未达90%目标，ERAM87/108已达标；setup+0.002ns、hold+0.020ns、TNS0。以上均为真实最终结果，不以中间估计替代。原分类/计数/按键未改，无推送/板卡/用户GUI操作。
''',encoding='utf-8')
print(proof['status'])
