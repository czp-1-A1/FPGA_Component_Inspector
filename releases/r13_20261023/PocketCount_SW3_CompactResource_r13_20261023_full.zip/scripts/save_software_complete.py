from pathlib import Path
import json,datetime
r=Path(__file__).parent;c=r/'stage_B_r3';sw=json.loads((c/'software_running.json').read_text());assert sw['status']=='PASS72_AND_TEN_NATIVE_PLUS_RGB_REFERENCE'
phy=json.loads((r/'physical_r0/running.json').read_text());delivery=json.loads((r/'delivery_workflow.json').read_text());s=json.loads((r/'current_status.json').read_text())
s.update(status='R13_COMPLETE_SOFTWARE_PASS_PHY_RUNNING',updated=datetime.datetime.now().isoformat(),actual_passed=25,actual_required=25,identical_reused=47,running=dict(physical=phy['pid'],one_shot_delivery=delivery['pid']),software=sw['status'],next='PHY running same frozen471/SDC/seed2. Final routed setup/hold>=0,TNS0 and complete46/20Gray/6mailbox/SW3 audit required. One-shot packaging and independent Desktop archive/fresh94 restore already waiting; do not duplicate. No board/GUI/Git or automation changes.')
(r/'current_status.json').write_text(json.dumps(s,indent=2),encoding='utf-8')
f=r/'AGENTS.md';old=f.read_text(encoding='utf-8');new=old.replace('当前完整软件父8732（25项变化输入重跑，已通过15项，47项严格同实际编译/runtime SHA复用）；物理父15576已SYN通过，Gate19265Slice/ERAM87/DSP28/PLL5（非最终路由），门控等待72项+10 native/RGB及补充通过后才PHY','完整72软件、10 native独立参考/86RGB/44字段绑定已通过（25实际重跑/47同SHA复用），软件父8732和证据后处理32496均已结束；原未改校验器要求全新HEX库存，旧目录缺compact_assets被如实保留失败，47旧实跑的逐SHA源码/日志/图像复制到独立restaged_reused_evidence补齐未读取的新增字库HEX库存，原目录未改、不假称重跑、无排除或修改校验器/答案，provenance详表已保存；物理父15576已开始同SDC/seed2最终PHY，SYN Gate19265Slice/ERAM87/DSP28/PLL5仍非最终值')
new=new.replace('- 无子代理/板卡/JTAG/Flash/用户GUI/提交推送；automation/r12保持PAUSED，不创建/恢复跟进。原镜像/冻结/失败证据不覆盖。','- 用户新要求继续运行、交付统一精简bit供实板复测，不能影响原功能。追加不改DUT的动态RGB专项：r0期望队列未复位造成106ns假失败，r1只修独立记分器复位，约930274时钟旁路/921600有效像素/163200未覆盖动态像素三拍延迟与RGB完全一致，源码与原期望属性不变，失败/复测分开保留。全部原分类/计数/按键/视频核心及约束/原bench逐SHA已再次核对，preserved_function_preflight.json。\n- 无子代理/板卡/JTAG/Flash/用户GUI/提交推送；automation/r12保持PAUSED，不创建/恢复跟进。原镜像/冻结/失败证据不覆盖。')
assert new!=old;f.write_text(new,encoding='utf-8');f=Path('C:/Users/Li47/Desktop/aa/AGENTS.md');whole=f.read_text(encoding='utf-8-sig');assert whole.count(old)==1;f.write_text(whole.replace(old,new,1),encoding='utf-8')
folder=r/'开发实施/验收记录';folder.mkdir(parents=True,exist_ok=True)
(folder/'20261023_R13_原功能保留与软件证据补全_轮次2.md').write_text('''# R13 原功能保留与独立证据补全

冻结stage_B_r3全部471输入，manifest243651b68a39160cfb81efe91b11836bcb32109750ecd29793530fca1bc98c65，无生产源或旧测试答案变化。

72项完整验收通过：25项受容量/包装器变化影响实际重新编译与运行，47项实际编译/runtime输入同SHA结果复用。10套RAW独立像素参考、86帧RGB参考、44源帧逐字段及原像素编号绑定通过。

完整汇总首次未通过：原校验器按全冻结清单要求所有HEX库存，旧实跑目录没有本次新增的compact_assets三份HEX。它们是字库/模板RTL字面ROM的参考副本，旧编译输入中均无读取这些文件的引用。没有修改校验器、删减清单或触碰旧目录：在独立restaged_reused_evidence中复制完整新库存、实际旧源码/原compile和console/原PGM，逐SHA证明每个旧编译输入及原runtime清单不变、日志同字节，明确标注不是重新执行；完整原校验器随后PASS。原运行目录及失败日志/原软件运行映射保留，evidence_restage_provenance.json可追溯47项的真实原始路径。

新增动态RGB专项：完全隔离冻结DUT/新独立测试台。r0在106ns失败，原因是记分器期望队列未随复位清零，与DUT初始零管线不一致；r1仅修测试台复位，三拍RGB/HS/VS/DE属性不变，原921600有效像素与163200未覆盖像素覆盖目标不变。r1约930274时钟旁路、全帧及动态未覆盖像素比较通过。两个版本的测试台SHA、实际编译日志、失败/成功console均保留，DUT SHA完全相同。

原功能检查：除6行缓存/包装器、双页路由/production参数及工程/测试源列表，所有原分类、阈值、计数、ROI、按键、缩放、视频与CDC、约束及原bench原字节。新UI四完整720p共3686400像素独立参考无差。灰度采样与目标特征来源在烧录说明中明确，CAL诊断HEX格式注明。

本记录时PHY已启动，同原SDC/预定seed2，尚不作时序通过或实物计数通过结论。最终报告和独立桌面归档恢复以交付回执为准。未操作板卡/JTAG/Flash/用户GUI，无子代理，无提交/推送，automation/r12继续暂停。
''',encoding='utf-8')
print(s['status'])
