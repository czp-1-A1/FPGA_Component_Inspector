from pathlib import Path
import subprocess,sys,json,os,datetime
r=Path(__file__).parent;s=dict(status='PACKAGING_VERIFIED_R13_SAME_BIT_CORRECTED_DEPENDENCY_INVENTORY',pid=os.getpid(),hardware_operation=False)
def save():(r/'delivery_workflow_r1.json').write_text(json.dumps(s,indent=2),encoding='utf-8')
save()
try:
 for name in ['package_r13_r1.py','verify_archive_r13_r1.py']:
  s['phase']=name;save();subprocess.run([sys.executable,str(r/name)],check=True)
 receipt=json.loads((r/'delivery_receipt.json').read_text());assert receipt['status']=='COMPLETE_INDEPENDENT_ARCHIVE_RESTORE_VERIFIED_HUMAN_BOARD_PENDING'
 s.update(status='COMPLETE_INDEPENDENT_DESKTOP_DELIVERY_VERIFIED',phase='COMPLETE',completed=datetime.datetime.now().isoformat(),bit_sha256=receipt['bit_sha256'],desktop=list(receipt['desktop']));save()
 print(s['status'],flush=True)
except Exception:
 import traceback;s.update(status='FAIL_RETAINED',error=traceback.format_exc());save();raise
