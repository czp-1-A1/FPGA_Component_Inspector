from pathlib import Path
import json,hashlib,shutil,sys
r=Path(__file__).parent;old=r/sys.argv[1];c=r/sys.argv[2];p=r/'development/fpga/component_inspector'
assert not c.exists();source=c/'source_snapshot';source.mkdir(parents=True)
manifest={}
keys=set(json.loads((old/'inputs.json').read_text()))
keys.update(q.relative_to(p).as_posix() for q in p.rglob('*') if q.is_file() and ('compact_' in q.name or 'compact_assets' in str(q)))
for rel in sorted(keys):
 d=source/rel;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p/rel,d);manifest[rel]=hashlib.sha256(d.read_bytes()).hexdigest()
(c/'inputs.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
before=json.loads((old/'inputs.json').read_text());changed=[q for q in manifest if before.get(q)!=manifest[q]]
(c/'iteration.json').write_text(json.dumps({'previous':str(old),'changes':changed,'reason':sys.argv[3],'test_answers_unchanged':all(not q.startswith('sim/tb_') for q in changed)},indent=2),encoding='utf-8')
print(len(manifest),hashlib.sha256((c/'inputs.json').read_bytes()).hexdigest(),changed)
