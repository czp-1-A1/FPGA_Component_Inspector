from pathlib import Path
import json,hashlib,os,subprocess,time,sys,re,importlib.util
r=Path(__file__).parent;c=r/'stage_B_r3';base=r/'physical_r0';p=base/'fpga/component_inspector';logs=base/'logs'
assert not base.exists();logs.mkdir(parents=True)
manifest=json.loads((c/'inputs.json').read_text());assert len(manifest)==471
spec=importlib.util.spec_from_file_location('prepare',Path('D:/CodexWork/classified_multithreshold_empty_20261022/prepare_portable_project.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.prepare(c/'source_snapshot',c/'inputs.json',p,Path('D:/td6.2.1'))
cfg=p/'td_project/camera_to_dsi_display_Runs/phy_1/settings.cfg';s=cfg.read_text();assert len(re.findall(r'place seed \d+',s))==1
cfg.write_text(re.sub(r'place seed \d+','place seed 2',s),encoding='utf-8')
state=dict(status='RUNNING',phase='SYN',pid=os.getpid(),candidate='stage_B_r3',seed=2,manifest_sha256=hashlib.sha256((c/'inputs.json').read_bytes()).hexdigest(),hardware_operation=False)
def save():(base/'running.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
save();env=os.environ.copy();temp=logs/'temp';temp.mkdir();env.update(TEMP=str(temp),TMP=str(temp))
def read(q):
 b=q.read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
def run(stage,command,cwd):
 state['phase']=stage;save();t=time.time()
 with (logs/(stage+'.log')).open('wb') as f:code=subprocess.run(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,env=env).returncode
 state[stage]=dict(exit_code=code,seconds=time.time()-t);save()
 if code:state['status']='FAIL_RETAINED';save();raise SystemExit(1)
 print('PASS',stage,flush=True)
td='D:/td6.2.1/bin/td_commands_prompt.exe'
run('SYN',[td,'build.tcl'],p/'td_project/camera_to_dsi_display_Runs/syn_1')
area=read(p/'td_project/camera_to_dsi_display_Runs/syn_1/camera_to_dsi_display_gate.area')
state['SYN_resources']={k:int(re.search(r'^#'+k+r'\*?\s+(\d+)',area,re.M)[1]) for k in ['slice','eram','dsp','pll']}
state['phase']='WAIT_COMPLETE_SOFTWARE_GATE';save()
while True:
 q=c/'software_running.json'
 if q.exists():
  try:sw=json.loads(q.read_text())
  except json.JSONDecodeError:time.sleep(1);continue
  if sw['status']=='FAIL':state.update(status='SOFTWARE_FAILED_PHY_NOT_STARTED');save();raise SystemExit(1)
  if sw['status']=='PASS72_AND_TEN_NATIVE_PLUS_RGB_REFERENCE':break
 time.sleep(5)
proof=json.loads((c/'software_verification.json').read_text());assert proof['status']=='PASS72_FROZEN_ACTUAL_COMPILED_INPUTS_NO_EXCLUSIONS' and len(proof['tests'])==72
assert proof['manifest_sha256']==state['manifest_sha256']
assert json.loads((c/'independent_pixels/verification.json').read_text())['status']=='PASS'
assert json.loads((c/'units_running.json').read_text())['status']=='PASS_RUNTIME_INDEPENDENT_REFERENCE_PENDING'
unit=json.loads((r/'stage_A_r0/unit_verification.json').read_text())
for test,record in unit['tests'].items():
 for rel,digest in record['inputs'].items():assert manifest[rel]==digest,(test,rel)
for rel,digest in manifest.items():
 if rel.startswith('user_source/') or rel.endswith('.sdc'):assert hashlib.sha256((p/rel).read_bytes()).hexdigest()==digest,rel
run('PHY',[td,'build.tcl'],p/'td_project/camera_to_dsi_display_Runs/phy_1')
run('AUDIT',[td,'tools/classified_audit_routed.tcl'],p)
run('VERIFY',[sys.executable,'tools/verify_classified_physical.py',str(p)],p)
state.update(status='PASS_ROUTED_COMPLETE_AUDIT',phase='COMPLETE');save();print(state['status'],flush=True)
