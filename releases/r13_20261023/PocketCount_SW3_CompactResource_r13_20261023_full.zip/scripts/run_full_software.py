from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,subprocess,shutil,time,sys,os,importlib.util
root=Path(__file__).parent;c=root/'stage_B_r3';source=c/'source_snapshot';manifest=json.loads((c/'inputs.json').read_text(encoding='utf-8'))
prior=json.loads((Path('D:/CodexWork/classified_multithreshold_empty_20261022/candidate_r0/software_verification.json')).read_text(encoding='utf-8'))
required=json.loads((c/'required_tests.json').read_text(encoding='utf-8'))['required_tests'];out=c/'regression';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for r,h in manifest.items():assert sha(source/r)==h,r
reuse=[];rerun=[]
for n in required:
 t=prior['tests'].get(n)
 if t and all(manifest.get(r)==h for r,h in t['inputs'].items()) and all(manifest.get(r)==h for r,h in t['runtime_inputs'].items()):reuse.append({'project':t['origin'],'tests':[n],'reuse_reason':'All actual compiled RTL/bench and runtime inputs byte identical; no elaboration exemptions'})
 else:rerun.append(n)
# Long native cases begin first; each test has an isolated project/runtime dir.
native_order=['dual_motion','dual_guard','dual_phase','dual_page','dual_raw_motion','local_raw_motion','local_pipeline','local_stream','local_capacity','local_page','velocity_bootstrap','start_speed','velocity_pipeline','velocity_recovery','start_entry_raw','speed_raw','recovery_raw_motion','ordered_raw_motion','tail_recovery_raw','motion_recovery_raw','result_recorder_raw_motion','classified_raw_motion']
rerun.sort(key=lambda n:(native_order.index(n) if n in native_order else 10,n))
(c/'rerun_plan.json').write_text(json.dumps({'actual':rerun,'identical_reused':reuse},indent=2),encoding='utf-8')
state={'status':'RUNNING','pid':os.getpid(),'actual_required':rerun,'completed':[],'reused':len(reuse)}
def save():
 tmp=c/'software_running.tmp';tmp.write_text(json.dumps(state,indent=2),encoding='utf-8');tmp.replace(c/'software_running.json')
save()
def run(n):
 p=out/n/'fpga/component_inspector'
 for r in manifest:
  d=p/r;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/r,d)
 # Lossless NTFS compression of copied immutable font/reference HEX only.
 hexes=[str(p/r) for r in manifest if r.lower().endswith('.hex')]
 for i in range(0,len(hexes),8):subprocess.run(['compact.exe','/C','/I','/Q',*hexes[i:i+8]],stdout=subprocess.DEVNULL,check=True)
 script=out/n/'run.ps1';log=out/n/'runner.log'
 q=lambda x:"'"+str(x).replace("'","''")+"'"
 script.write_text("$ErrorActionPreference='Stop'\n& "+q(p/'sim/run_modelsim.ps1')+" -ModelSimBin 'D:/modeltech64_10.5/win64' -TdSimRoot 'D:/td6.2.1/sim_release' -OnlyTests @("+q(n)+') *> '+q(log)+'\nif ($LASTEXITCODE -ne 0) {exit 1}\n',encoding='utf-8')
 start=time.time();code=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)]).returncode
 return n,p,code,time.time()-start
def compact_and_clean_pass(project,name):
 folder=project/'sim/modelsim_work'/name
 def readlog(p):
  b=p.read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
 text=readlog(folder/'console.log');assert 'PASS ' in text and '** Fatal' not in text
 removed=[]
 cache=(project/'sim/modelsim_work').resolve();cache.relative_to(root)
 for p in cache.rglob('*'):
  if p.is_file() and p.suffix.lower() in {'.qdb','.qpg','.qtl','.qst','.wlf'}:
   p=p.resolve();p.relative_to(cache);removed.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)});p.unlink()
 (project/'pass_cache_removal.json').write_text(json.dumps({'test':name,'console_sha256':sha(folder/'console.log'),'only_reproducible_pass_binary_cache':True,'removed':removed},indent=2),encoding='utf-8')
 with (project/'lossless_compression.log').open('wb') as log:
  subprocess.run(['compact.exe','/C','/S:'+str(project),'/I','/Q','*.hex','*.pgm','*.ppm','*.log','*.v','*.sv','*.py'],stdout=log,stderr=subprocess.STDOUT,check=True)

origins=list(reuse);failures=[]
with ThreadPoolExecutor(max_workers=5) as pool:
 futures=[pool.submit(run,n) for n in rerun]
 for future in as_completed(futures):
  try:n,p,code,elapsed=future.result()
  except Exception as e:failures.append(str(e));state['failures']=failures;save();continue
  state['completed'].append({'test':n,'exit_code':code,'seconds':elapsed});save();print(n,'PASS' if code==0 else 'FAIL',round(elapsed,1),flush=True)
  if code:failures.append(n)
  else:
   origins.append({'project':str(p),'tests':[n]})
   compact_and_clean_pass(p,n)
if failures:
 state.update(status='FAIL',failures=failures);save();raise SystemExit(1)
config={'required_tests':required,'origins':origins};(c/'software_runs.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
spec=importlib.util.spec_from_file_location('verifier',source/'tools/verify_result_recorder_software.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.verify(c/'inputs.json',source,c/'software_runs.json',c/'software_verification.json')
for n,tool in [('recovery_raw_motion','check_recovery_raw_reference.py'),('ordered_raw_motion','check_ordered_raw_reference.py'),('tail_recovery_raw','check_tail_recovery_raw_reference.py'),('motion_recovery_raw','check_motion_recovery_raw_reference.py'),('result_recorder_raw_motion','check_result_recorder_raw_reference.py'),('classified_raw_motion','check_classified_raw_reference.py')]:
 p=Path(next(o['project'] for o in origins if n in o['tests']))
 subprocess.run([sys.executable,str(source/'tools'/tool),str(p/'sim'),'--output',str(c/(n+'_independent_reference.json'))],check=True)

for n in ['start_entry_raw','speed_raw']:
 p=Path(next(o['project'] for o in origins if n in o['tests']))
 subprocess.run([sys.executable,str(source/'tools/check_start_speed_raw_reference.py'),str(p/'sim'),'--test',n,'--output',str(c/(n+'_independent_reference.json'))],check=True)
subprocess.run([sys.executable,str(root/'compare_original_ui_native.py')],check=True)
subprocess.run([sys.executable,str(root/'verify_new_native_protocol.py'),str(c)],check=True)
p=Path(next(o['project'] for o in origins if 'local_raw_motion' in o['tests']))
subprocess.run([sys.executable,str(source/'tools/check_local_raw_reference.py'),'--source',str(source),'--sim',str(p/'sim'),'--output',str(c/'local_raw_motion_independent_reference.json')],check=True)
p=Path(next(o['project'] for o in origins if 'dual_raw_motion' in o['tests']))
subprocess.run([sys.executable,str(source/'tools/check_dual_raw_reference.py'),str(p/'sim'),'--test','dual_raw_motion','--output',str(c/'dual_raw_motion_independent_reference.json')],check=True)
p=Path(next(o['project'] for o in origins if 'dual_motion' in o['tests']))
subprocess.run([sys.executable,str(source/'tools/check_dual_rgb_reference.py'),str(p/'sim'),'--output',str(c/'dual_motion_independent_reference.json')],check=True)
state.update(status='PASS72_AND_TEN_NATIVE_PLUS_RGB_REFERENCE' ,actual_runs=len(rerun),identical_reused=len(reuse));save();print(state['status'],flush=True)
