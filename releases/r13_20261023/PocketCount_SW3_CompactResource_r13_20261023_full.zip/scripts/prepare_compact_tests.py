from pathlib import Path
import re,json,hashlib,shutil
r=Path(__file__).parent;p=r/'development/fpga/component_inspector';sim=p/'sim'
s=(sim/'tb_dual_page.v').read_text()
inst=s[s.index('classified_dual_page_osd #('):s.index('experiment_osd #(')]
inst=inst.replace('#(.CLASSIFIED_COUNT(1)','#(.COMPACT_UI(1),.CLASSIFIED_COUNT(1)',1)
for a,b in [('.roi_mean(8\'d100)',".roi_mean(8'd149)"),('.roi_min(8\'d30)',".roi_min(8'd124)"),('.roi_max(8\'d180)',".roi_max(8'd176)"),('.calibration_record(128\'d0)','.calibration_record(cal)'),('.calibration_valid(1\'b0)',".calibration_valid(1'b1)"),('.count_eligible(1\'b1)','.count_eligible(eligible)')]:inst=inst.replace(a,b)
bench='''`timescale 1ns/1ps
module tb_compact_ui;
reg clk=0,rst_n=0,vs=0,hs=0,de=0,page_switch=1,eligible=1;
always #5 clk=~clk;
reg [255:0] live=0,packet=0;reg [303:0] objects=0;reg [127:0] cal=0;
wire nv,nh,nd;wire [23:0] nrgb;
integer f=0,fd,px=0,n=0,xx,yy;reg [2:0] vp=0,hp=0,dp=0;
'''+inst+'''
always @(posedge clk)begin
 vp<={vp[1:0],vs};hp<={hp[1:0],hs};dp<={dp[1:0],de};
 #1;
 if(rst_n)begin
  if({nv,nh,nd}!=={vp[2],hp[2],dp[2]})$fatal(1,"three-clock video/control alignment");
  if(nd)begin
   $fwrite(fd,"%06x\\n",nrgb);px=px+1;
   if(^nrgb===1'bx)$fatal(1,"unknown output pixel");
  end
 end
end
task tick;input integer count;integer i;begin for(i=0;i<count;i=i+1)@(negedge clk);end endtask
function [75:0] object;
 input [1:0] kind;input [3:0] reason;input [10:0] x0,x1;input [9:0] y0,y1;
 begin object={1'b1,kind,reason,13'd956,7'd32,7'd32,x0,x1,y0,y1};end
endfunction
task picture;
 input integer index;reg [255:0] saved;reg [303:0] saved_objects;
 begin
  f=index;px=0;
  case(index)
   0:fd=$fopen("compact_0.hex","w");1:fd=$fopen("compact_1.hex","w");
   2:fd=$fopen("compact_2.hex","w");default:fd=$fopen("compact_3.hex","w");
  endcase
  vs=1;tick(4);vs=0;tick(10);
  saved=live;saved_objects=objects;
  for(yy=0;yy<720;yy=yy+1)begin
   hs=1;tick(2);hs=0;de=1;
   for(xx=0;xx<1280;xx=xx+1)tick(1);
   de=0;tick(10);
   if(yy==300)begin live=~saved;objects=~saved_objects;end
  end
  tick(8);live=saved;objects=saved_objects;
  if(px!=921600)$fatal(1,"pixel count %d",px);
  $fclose(fd);
 end
endtask
initial begin
 tick(10);rst_n=1;tick(8);
 live[47:32]=7;live[50:48]=2;live[55]=1;live[56]=1;
 live[66:58]=27;live[75:67]=20;live[84:76]=7;live[93:85]=2;live[239:224]=65535;
 live[210:202]=27;live[212:211]=3;live[255:240]=16'h4021;
 live[130+:9]=1;live[139+:9]=9;live[148+:9]=13;live[157+:9]=14;
 live[166+:9]=15;live[175+:9]=20;live[184+:9]=24;
 packet=live;packet[31:0]=32'h89abcdef;packet[94+:9]=8;packet[103+:9]=9;
 objects[75:0]=object(2,0,550,581,300,331);
 objects[151:76]=object(3,0,650,659,310,319);
 objects[227:152]=object(2,1,550,581,470,501);
 objects[303:228]=object(1,2,690,711,480,497);
 cal[63:0]={1'b1,1'b1,2'd3,8'd148,8'd124,8'd176,9'd0,13'd956,7'd32,7'd32};
 cal[127:64]=cal[63:0];
 picture(0);
 page_switch=0;tick(742520);
 live[112+:9]=9;packet[112+:9]=9;packet[31:0]=32'h12345678;
 picture(1);
 live=0;eligible=0;picture(2);
 live[47:32]=8;live[50:48]=2;eligible=1;picture(3);
 $display("PASS compact UI: four full HD rasters, metadata frozen midframe, page switch, clear and generation guard; independent pixel reference pending");
 $finish;
end
initial begin #200000000;$fatal(1,"timeout");end
endmodule
'''
(sim/'tb_compact_ui.sv').write_text(bench,encoding='ascii')
f=sim/'run_modelsim.ps1';s=f.read_text();tag='    $tests = @(\n';assert tag in s
item='''        @{Name="compact_ui"; Pass="PASS compact UI:"; Sources=@("$hdl/bin16_bcd.v", "$hdl/osd_ascii_rom.v", "$hdl/osd_cjk_rom.v", "$hdl/osd_logo_rom.v", "$hdl/inspection_region_config.v", "$hdl/experiment_osd.v", "$hdl/classified_count_renderer.v", "$hdl/compact_inspector_osd.v", "$hdl/compact_cjk_rom.v", "$hdl/compact_template_rom.v", "$hdl/classified_dual_page_osd.v", "tb_compact_ui.sv")},
'''
assert 'Name="compact_ui"' not in s
f.write_text(s.replace(tag,tag+item,1),encoding='utf-8-sig')
base=json.loads((r/'stage_A_r0/inputs.json').read_text())
new=[str(q.relative_to(p)).replace('\\','/') for q in p.rglob('*') if q.is_file() and ('compact_' in q.name or 'compact_assets' in str(q))]
manifest={}
c=r/'stage_B_r0';assert not c.exists();source=c/'source_snapshot';source.mkdir(parents=True)
for rel in sorted(set(base)|set(new)):
 q=p/rel;dst=source/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,dst);manifest[rel]=hashlib.sha256(dst.read_bytes()).hexdigest()
(c/'inputs.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('Frozen B',len(manifest),hashlib.sha256((c/'inputs.json').read_bytes()).hexdigest())
