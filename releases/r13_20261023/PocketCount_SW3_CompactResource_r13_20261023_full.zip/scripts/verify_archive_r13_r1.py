"""Independent Desktop archive, source, log and fresh project restore audit."""
from pathlib import Path
import json,hashlib,zipfile,importlib.util,datetime
R=Path(__file__).parent;NAME='PocketCount_SW3_CompactResource_r13_20261023';D=Path('C:/Users/Li47/Desktop')
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 receipt=json.loads((R/'delivery_receipt.json').read_text(encoding='utf-8'))
 for name,row in receipt['desktop'].items():
  b=Path(name).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],name
 assert json.loads((D/(NAME+'_交付回执.json')).read_text(encoding='utf-8'))==receipt
 restored=R/'archived_replay_r13_r1';restored.mkdir(exist_ok=False)
 with zipfile.ZipFile(D/(NAME+'_full.zip')) as z:
  assert z.testzip() is None;payload=json.loads(z.read('PAYLOAD_SHA256.json'))
  assert len(payload)==receipt['archive_payload_entries'] and set(z.namelist())==set(payload)|{'PAYLOAD_SHA256.json'}
  for rel,row in payload.items():
   b=z.read(rel);assert len(b)==row['bytes'] and sha(b)==row['sha256'],rel
  raw=z.read('frozen_inputs.json');assert sha(raw)==receipt['source_manifest_sha256'];manifest=json.loads(raw);assert len(manifest)==471
  for rel in ['frozen_inputs.json','scripts/prepare_portable_project.py']+['fpga/component_inspector/'+q for q in manifest]:
   p=restored/rel;p.resolve().relative_to(restored.resolve());p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(rel))
  sw=json.loads(z.read('validation/software_verification.json'));assert len(sw['tests'])==72 and sw['manifest_sha256']==receipt['source_manifest_sha256']
  for name,row in sw['tests'].items():
   for group in ['inputs','runtime_inputs']:
    for rel,h in row[group].items():assert manifest[rel]==h,(name,rel)
   for filename,key in [('compile.log','compile_sha256'),('console.log','console_sha256')]:assert sha(z.read('validation/tests/'+name+'/'+filename))==row[key]
  provenance=json.loads(z.read('validation/evidence_restage_provenance.json'));assert len(provenance['tests'])==47
  for row in provenance['tests']:
   name=row['test'];current=sw['tests'][name];assert row['not_a_new_simulation'] and row['actual_compiled_inputs']==current['inputs']
   assert row['compile_sha256']==current['compile_sha256'] and row['console_sha256']==current['console_sha256']
   for rel,h in row['actual_prior_reference_inventory'].items():assert current['runtime_inputs'][rel]==h
   assert all(rel.startswith('sim/compact_assets/') for rel in row['new_unused_inventory_files'])
  supp=json.loads(z.read('validation/supplement_verification.json'));assert supp['manifest_sha256']==receipt['source_manifest_sha256']
  for name,row in supp['unit_tests'].items():
   for rel,h in row['inputs'].items():assert manifest[rel]==h
   for filename,key in [('compile.log','compile_sha256'),('console.log','console_sha256')]:assert sha(z.read('validation/compact_ui/tests/'+name+'/'+filename))==row[key]
  for name,row in supp['capacity_reused_actual_compiled_SHA'].items():
   for rel,h in row['inputs'].items():assert manifest[rel]==h
   for filename,key in [('compile.log','compile_sha256'),('console.log','console_sha256')]:assert sha(z.read('validation/capacity/stage_A/'+name+'/'+filename))==row[key]
  pix=json.loads(z.read('validation/compact_ui/verification.json'));assert pix['status']=='PASS'
  for row in pix['frames']:
   assert row['mismatch']==0 and row['pixels']==921600 and sha(z.read(f"validation/compact_ui/raw/compact_{row['frame']}.hex"))==row['captured_sha256']
  dynamic=json.loads(z.read('validation/rgb_passthrough_r1/verification.json'));assert dynamic['status']=='PASS_CHANGING_RGB_AND_CONTROL_THREE_CLOCK_BYPASS_AND_CLEAR_PICTURE'
  assert dynamic['source_manifest_sha256']==receipt['source_manifest_sha256']
  for rel,h in dynamic['inputs'].items():assert manifest[rel]==h
  for filename,key in [('compile.log','compile_sha256'),('console.log','console_sha256'),('tb_compact_rgb.sv','bench_sha256')]:assert sha(z.read('validation/rgb_passthrough_r1/'+filename))==dynamic[key]
  for name in ['dual_raw_motion','local_raw_motion','start_entry_raw','speed_raw','recovery_raw_motion','ordered_raw_motion','tail_recovery_raw','motion_recovery_raw','result_recorder_raw_motion','classified_raw_motion']:
   ref=json.loads(z.read('validation/'+name+'_independent_reference.json'));assert ref['status'].startswith('PASS_')
   for frame in ref['frames']:assert sha(z.read('validation/native/'+name+'/region_cadence_'+str(frame['frame'])+'.pgm'))==frame['pgm_sha256']
  rgb=json.loads(z.read('validation/dual_motion_independent_reference.json'));assert rgb['source_frames']==86 and rgb['status'].startswith('PASS_')
  for frame in rgb['frames']:assert sha(z.read('validation/rgb/dual_rgb_'+str(frame['direction'])+'_'+str(frame['frame'])+'.pgm'))==frame['pgm_sha256']
 spec=importlib.util.spec_from_file_location('prepare',restored/'scripts/prepare_portable_project.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 fresh=R/'archived_prepared_r13_r1/fpga/component_inspector';prepared=m.prepare(restored/'fpga/component_inspector',restored/'frozen_inputs.json',fresh,Path('D:/td6.2.1'));proof=json.loads((R/'project_dependency_delta.json').read_text(encoding='utf-8'));assert set(prepared['inputs'])==set(proof['expected_dependencies']) and len(prepared['inputs'])==98
 for rel,h in manifest.items():
  if rel.startswith('user_source/') or rel.endswith('.sdc'):assert sha((fresh/rel).read_bytes())==h,rel
 result=dict(status='PASS_DESKTOP_ALL_PAYLOAD_FROZEN471_TEST72_CAPACITY_COMPACT3686400_TEN_NATIVE_RGB86_FRESH98_PROJECT',bit_sha256=receipt['bit_sha256'],payload_entries=len(payload),frozen_inputs=471,software_tests=72,compact_ui_pixels=3686400,native_references=10,rgb_frames=86,project_ip_dependencies=98,hardware_programmed=False,created=datetime.datetime.now().isoformat())
 (R/'archive_delivery_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 receipt.update(status='COMPLETE_INDEPENDENT_ARCHIVE_RESTORE_VERIFIED_HUMAN_BOARD_PENDING',independent_archive_verification=result)
 for q in [R/'delivery_receipt.json',D/(NAME+'_交付回执.json')]:q.write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf-8')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
