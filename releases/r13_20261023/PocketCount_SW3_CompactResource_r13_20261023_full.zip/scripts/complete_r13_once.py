"""One-shot build continuation; no scheduling, GUI, board or notifications."""
from pathlib import Path
import json,time,subprocess,sys,os,datetime,traceback,hashlib
r=Path(__file__).parent;status=r/'delivery_workflow.json'
assert not status.exists()
s=dict(status='WAITING_VERIFIED_BUILD',pid=os.getpid(),candidate='stage_B_r3',hardware_operation=False,automation='automation/r12 remain PAUSED')
def save():status.write_text(json.dumps(s,indent=2),encoding='utf-8')
def read(q):
 try:return json.loads(q.read_text(encoding='utf-8-sig'))
 except (FileNotFoundError,json.JSONDecodeError):return {}
save()
try:
 while True:
  phy=read(r/'physical_r0/running.json');sw=read(r/'stage_B_r3/software_running.json')
  if 'FAIL' in phy.get('status','') or 'FAIL' in sw.get('status',''):raise RuntimeError('Build/software failed; no package or Desktop delivery attempted')
  if phy.get('status')=='PASS_ROUTED_COMPLETE_AUDIT' and sw.get('status')=='PASS72_AND_TEN_NATIVE_PLUS_RGB_REFERENCE':break
  time.sleep(10)
 s['status']='PACKAGING_VERIFIED_CANDIDATE';save()
 record=r/'开发实施/验收记录/20261022_R13_资源优化与双页精简_轮次1.md';record.parent.mkdir(parents=True,exist_ok=True)
 text='''# R13 资源优化与双页精简，冻结软件与物理验证

源：stage_B_r3/471输入，manifest 243651b68a39160cfb81efe91b11836bcb32109750ecd29793530fca1bc98c65。基线为R12 candidate_r0，原分类/阈值/计数/ROI/SDC与全部原bench字节不变。

A缓存：480组/行的1920/PPC4客户端从11位2048深缩至9位512，包装器默认旧深度兼容。实际原厂RAM模型三尺寸双DUT比较数据/valid/帧/地址/断续/早SOF/复位，以及manual_wb/fixed_wb通过。

B共享UI：同一ASCII字库、七中文字、原Logo、单数字转换与双页模板。中文有件/空穴/待复核、上下栏与ROI主要位置保留，去大卡/长说明。四完整720p画面3686400像素独立字面/原字模参考完全相同，三时钟、切页、源帧快照、清零与旧段守卫通过。

原72软件用真实编译/runtime输入逐SHA严格核对；本轮25变化输入实际重跑、47同SHA结果复用，10真实RAW独立像素参考与86RGB源帧参考。参考期望和旧测试未改。

保留失败：初始化GBK注释读取/半初始化防护、Verilog保留字cell编译（只改标识符修复）、#slice*后处理解析（未重跑SYN）、ASCII新增源列表shell引用预检（未构建，r3仅修列表）。额外旧pixel_interface诊断与不可变R12均185行38460ns相同失败，位于必测72之外，不删证据或称该诊断通过。

完整PHY同SDC/预定seed2：最终Routed setup/hold非负/TNS0、46max-delay匹配/Ignored0、20Gray8ns、6邮箱/SW3实际完整扇出审计通过。实测数值见build_evidence和release_verification.json，不能以中间Gate估计代替最终利用率。A独立SYN ERAM89；A+B独立SYN ERAM87、Slice19265、DSP28仅是中间值。

尚未上板，本次资源/UI优化不宣称高速漏空穴已解决；同镜像按说明做静止中文/原数据、切页/清零/四模式及已知载带慢/常用/较快速度复测。旧镜像/冻结/现场失败完整保留。未推送，未操作板卡/JTAG/Flash/用户TD窗口，无子代理；automation/r12保持暂停。
'''
 record.write_text(text,encoding='utf-8')
 for name in ['package_r13.py','verify_archive_r13.py']:
  s['phase']=name;save();subprocess.run([sys.executable,str(r/name)],check=True)
 receipt=read(r/'delivery_receipt.json');assert receipt.get('status')=='COMPLETE_INDEPENDENT_ARCHIVE_RESTORE_VERIFIED_HUMAN_BOARD_PENDING'
 s.update(status='COMPLETE_INDEPENDENT_DESKTOP_DELIVERY_VERIFIED',phase='COMPLETE',completed=datetime.datetime.now().isoformat(),bit_sha256=receipt['bit_sha256'],desktop=list(receipt['desktop']))
 save()
 cur=read(r/'current_status.json');cur.update(status='R13_DELIVERED_DESKTOP_INDEPENDENTLY_VERIFIED_HUMAN_BOARD_PENDING',updated=datetime.datetime.now().isoformat(),running={},new_bit=True,desktop=list(receipt['desktop']),bit_sha256=receipt['bit_sha256'],resources=receipt['resources'],next='Notify user with exact Desktop paths, resource/timing and frozen-image static/same-speed board checks. No auto follow-up; automation/r12 stay PAUSED.')
 (r/'current_status.json').write_text(json.dumps(cur,indent=2),encoding='utf-8')
 handoff=f'''## 当前断点（R13资源优化与双页精简，完整交付，待实板）

- 用户授权两页精简、保留测试数据和主要位置；有件/空穴/待复核中文及原安路Logo保留。已完成A缓存缩深与B共享显示，未改C检测缓存。分类/阈值/计数/ROI/SDC原字节保持R12。
- 唯一实施D:/CodexWork/classified_resource_opt_20261022；stage_B_r3冻结471输入，manifest243651b68a39160cfb81efe91b11836bcb32109750ecd29793530fca1bc98c65。无.git胶囊；只读Git仍lj4747-contest-work/479a30b426d3a7edcde280d7bb202155fde4f310。另一聊天R12D1 WIP/旧镜像/失败证据保留，未混入。
- 改6缓存RTL，1920/PPC4每行480组、9位512地址，包装默认11/2048兼容；新增compact_inspector_osd/compact_ascii_rom/compact_cjk_rom/compact_template_rom，dual_page新增默认关闭COMPACT_UI、production启用/.al列源。上/下栏紧凑诊断、小中文类别与编号，保留空号/C/FIRST/GAP。共享单数字转换、ASCII/七中文字/Logo/模板。
- 72原契约逐实际编译/runtime SHA严格通过，本轮25实际重跑/47同SHA复用；三容量/WB契约复用实际同编译SHA，三尺寸原厂RAM双DUT逐数据/valid/帧/地址/断续/早SOF/复位通过；新四帧720p共3686400像素与独立参考零差；10 native与86RGB帧独立参考、源帧/运行段绑定通过。原72 bench/答案原字节不改。
- 完整Routed同SDC/seed2，时序{json.dumps(receipt['timing_ns'])}；46max-delay匹配/Ignored0、20Gray8ns、6邮箱/SW3完整扇出通过。最终资源{json.dumps(receipt['resources'])}；Slice{receipt['resources']['slice']/21216*100:.2f}%、ERAM{receipt['resources']['eram']/108*100:.2f}%。目标是否通过见receipt targets，不用Gate中间估算作结论。DSP比R12增加1，显示模板索引映射的取舍已告知。
- 桌面C:/Users/Li47/Desktop/PocketCount_SW3_CompactResource_r13_20261022.bit，SHA{receipt['bit_sha256']}，1789539字节；同前缀_full.zip/_烧录与验收.md/_SHA256.txt/_交付回执.json全部逐SHA。完整载荷/471源码/72日志/容量与UI像素记录/10 native+86RGB/94依赖新目录恢复独立校验通过，archive_delivery_verification.json。旧文件不覆盖。
- 原GBK初始化、cell保留字编译、ASCII源列表预检、#slice*解析等修复记录保留。额外pixel_interface诊断与不可变R12均185行38460ns同失败，不在原72必测，不事后改答案或称该额外诊断通过。
- 下一条：通知用户新镜像路径与实测资源/时序，先静止SW4两页/中文Logo/数据/四模式/清零，后同一已知载带慢/常用/此前快速复测总数/P/E/空号与GAP，拍全上下栏。CAL数据HEX已在说明写明。实物计数/高速漏空穴未验收，不声称本次资源优化修复识别。等待同一冻结镜像人测反馈，不自行新建版本。
- 仿真/TD/单次交付均已结束或正在退出最后落盘，无子代理/板卡/JTAG/Flash/用户GUI/提交推送。automation/r12保持PAUSED，无新自动跟进；历史进程8732/15576/30320不可盲重启，须核对真实PID。
'''
 own=r/'AGENTS.md';previous=own.read_text(encoding='utf-8-sig');own.write_text(handoff,encoding='utf-8')
 entry=Path('C:/Users/Li47/Desktop/aa/AGENTS.md');whole=entry.read_text(encoding='utf-8-sig')
 if whole.count(previous)==1:entry.write_text(whole.replace(previous,handoff,1),encoding='utf-8')
 else:(r/'handoff_merge_needed.json').write_text(json.dumps({'reason':'Exact previous section not unique; preserve other writer content','new_handoff':str(own)}),encoding='utf-8')
 print(s['status'],flush=True)
except Exception:
 s.update(status='FAILED_RETAINED',error=traceback.format_exc());save();raise
