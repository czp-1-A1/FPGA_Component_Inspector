from pathlib import Path
p=Path(__file__).parent/'development/fpga/component_inspector'
f=p/'td_project/camera_to_dsi_display.al';s=f.read_text();tag='            <File Path="../user_source/hdl_source/compact_inspector_osd.v">'
assert tag in s and '../user_source/hdl_source/compact_ascii_rom.v' not in s
s=s.replace(tag,'            <File Path="../user_source/hdl_source/compact_ascii_rom.v"><FileInfo><Attr Name="UsedInSyn" Val="true"/><Attr Name="UsedInP&amp;R" Val="true"/><Attr Name="BelongTo" Val="design_1"/><Attr Name="CompileOrder" Val="231"/></FileInfo></File>\n'+tag,1)
f.write_text(s,encoding='utf-8')
f=p/'sim/run_modelsim.ps1';s=f.read_text(encoding='utf-8-sig');tag='"$hdl/compact_inspector_osd.v",';assert s.count(tag)==1
f.write_text(s.replace(tag,'"$hdl/compact_ascii_rom.v", '+tag,1),encoding='utf-8-sig')
print('Compact ASCII project and test source lists linked')
