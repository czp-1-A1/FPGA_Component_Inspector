"""Fail-closed packaging of the exact frozen, tested, routed resource candidate."""
from pathlib import Path
import json,hashlib,shutil,zipfile,importlib.util,re,datetime
R=Path(__file__).parent;C=R/'stage_B_r3';P=R/'physical_r0/fpga/component_inspector'
NAME='PocketCount_SW3_CompactResource_r13_20261022';D=Path('C:/Users/Li47/Desktop')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
def copy(a,b):
 assert a.is_file() and not b.exists(),(a,b)
 b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b);assert sha(a)==sha(b)
def tree(a,b,suffixes=None):
 for q in a.rglob('*'):
  if q.is_file() and (suffixes is None or q.suffix.lower() in suffixes):copy(q,b/q.relative_to(a))
def main():
 manifest=load(C/'inputs.json');sw=load(C/'software_verification.json');supp=load(C/'supplement_verification.json')
 assert len(manifest)==471 and load(C/'software_running.json')['status']=='PASS72_AND_TEN_NATIVE_PLUS_RGB_REFERENCE'
 assert sw['status']=='PASS72_FROZEN_ACTUAL_COMPILED_INPUTS_NO_EXCLUSIONS' and len(sw['tests'])==72 and sw['manifest_sha256']==sha(C/'inputs.json')
 assert load(R/'physical_r0/running.json')['status']=='PASS_ROUTED_COMPLETE_AUDIT'
 assert supp['manifest_sha256']==sha(C/'inputs.json') and supp['status'].startswith('PASS_CAPACITY_AND_COMPACT_UI')
 pixels=load(C/'independent_pixels/verification.json');assert pixels['status']=='PASS' and all(row['mismatch']==0 and row['pixels']==921600 for row in pixels['frames'])
 dynamic=load(R/'rgb_passthrough_r1/verification.json');assert dynamic['status']=='PASS_CHANGING_RGB_AND_CONTROL_THREE_CLOCK_BYPASS_AND_CLEAR_PICTURE' and dynamic['source_manifest_sha256']==sha(C/'inputs.json')
 for rel,h in dynamic['inputs'].items():assert manifest[rel]==h
 for rel,h in manifest.items():
  assert sha(C/'source_snapshot'/rel)==h,rel
  if rel.startswith('user_source/') or rel.endswith(('.sdc','.adc')):assert sha(P/rel)==h,rel
 for name,row in sw['tests'].items():
  origin=Path(row['origin']);folder=origin/'sim/modelsim_work'/name
  assert sha(folder/'compile.log')==row['compile_sha256'] and sha(folder/'console.log')==row['console_sha256']
  for group in ['inputs','runtime_inputs']:
   for rel,h in row[group].items():assert manifest[rel]==h and sha(origin/rel)==h,(name,rel)
 spec=importlib.util.spec_from_file_location('audit',P/'tools/verify_classified_physical.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);phy=m.verify(P)
 assert phy['max_delays_matched']==46 and phy['max_delays_ignored']==0 and phy['gray_bits_dominating']==20 and phy['new_mailbox_groups']==6
 area=read(P/'td_project/camera_to_dsi_display_Runs/phy_1/camera_to_dsi_display_phy.area')
 resources={k:int(re.search(r'^#'+k+r'\s+(\d+)',area,re.M)[1]) for k in ['slice','eram','dsp','pll']}
 assert resources['slice']<=21216 and resources['eram']<=108 and resources['dsp']<=40 and resources['pll']<=6
 bit=P/'td_project/camera_to_dsi_display_Runs/phy_1/camera_to_dsi_display.bit';assert bit.stat().st_size==1789539
 refs={}
 for name,n in {'classified_raw_motion':7,'result_recorder_raw_motion':7,'motion_recovery_raw':12,'tail_recovery_raw':12,'ordered_raw_motion':12,'recovery_raw_motion':18,'start_entry_raw':22,'speed_raw':11,'local_raw_motion':20,'dual_raw_motion':11}.items():
  row=load(C/(name+'_independent_reference.json'));assert row['status'].startswith('PASS_') and row['source_frames']==n;refs[name]=row
 rgb=load(C/'dual_motion_independent_reference.json');assert rgb['source_frames']==86 and rgb['status'].startswith('PASS_')
 tool=load(Path('D:/CodexWork/classified_multithreshold_empty_20261022/release/PocketCount_SW3_DualThreshold_r12_20261022/validation/toolchain_manifest.json'))
 for path,h in tool['binaries'].items():assert sha(Path(path))==h
 for rel,h in tool['vendor_models'].items():assert sha(Path('D:/td6.2.1/sim_release')/rel)==h
 outputs=[D/(NAME+s) for s in ['.bit','_full.zip','_烧录与验收.md','_SHA256.txt','_交付回执.json']]
 assert not any(q.exists() for q in outputs)
 release=R/'release'/NAME;release.mkdir(parents=True,exist_ok=False)
 for rel in manifest:copy(C/'source_snapshot'/rel,release/'fpga/component_inspector'/rel)
 copy(C/'inputs.json',release/'frozen_inputs.json')
 for name in ['software_verification.json','software_runs.json','software_runs_before_restage.json','evidence_restage_provenance.json','postprocess_runtime_inventory_failure_r0.log','software_running.json','required_tests.json','supplement_verification.json','native_original_ui_identity.json','new_native_protocol_identity.json']:
  copy(C/name,release/'validation'/name)
 (release/'validation/toolchain_manifest.json').write_text(json.dumps(tool,indent=2),encoding='utf-8')
 copy(R/'preserved_function_preflight.json',release/'validation/preserved_function_preflight.json')
 for name,row in sw['tests'].items():
  sim=Path(row['origin'])/'sim';folder=sim/'modelsim_work'/name
  for filename in ['compile.log','console.log','transcript.log']:
   if (folder/filename).exists():copy(folder/filename,release/'validation/tests'/name/filename)
  if(sim/'modelsim_vendor_compile.log').exists():copy(sim/'modelsim_vendor_compile.log',release/'validation/tests'/name/'modelsim_vendor_compile.log')
 for name,row in refs.items():
  copy(C/(name+'_independent_reference.json'),release/'validation'/(name+'_independent_reference.json'));sim=Path(sw['tests'][name]['origin'])/'sim'
  for frame in row['frames']:
   q=sim/f"region_cadence_{frame['frame']}.pgm";assert sha(q)==frame['pgm_sha256'];copy(q,release/'validation/native'/name/q.name)
 copy(C/'dual_motion_independent_reference.json',release/'validation/dual_motion_independent_reference.json');sim=Path(sw['tests']['dual_motion']['origin'])/'sim'
 for frame in rgb['frames']:
  q=sim/f"dual_rgb_{frame['direction']}_{frame['frame']}.pgm";assert sha(q)==frame['pgm_sha256'];copy(q,release/'validation/rgb'/q.name)
 tree(C/'independent_pixels',release/'validation/compact_ui')
 for index in range(4):copy(C/f'units_r1/fpga/component_inspector/sim/compact_{index}.hex',release/'validation/compact_ui/raw'/f'compact_{index}.hex')
 tree(C/'sealed_reference_scripts',release/'validation/sealed_reference_scripts')
 for folder in ['rgb_passthrough_r0','rgb_passthrough_r1']:tree(R/folder,release/'validation'/folder,{'.sv','.json','.log'})
 for name in ['compact_ui','dual_page']:
  folder=C/'units_r1/fpga/component_inspector/sim/modelsim_work'/name
  for filename in ['compile.log','console.log','transcript.log']:copy(folder/filename,release/'validation/compact_ui/tests'/name/filename)
 for name in ['line_ram_equivalence','manual_wb','fixed_wb','pixel_interface']:
  for prefix,folder in [('stage_A',R/'stage_A_r0/units/fpga/component_inspector/sim/modelsim_work'/name),('immutable_R12',R/'pixel_baseline_r0/fpga/component_inspector/sim/modelsim_work'/name)]:
   if folder.exists():
    for filename in ['compile.log','console.log','transcript.log']:
     if (folder/filename).exists():copy(folder/filename,release/'validation/capacity'/prefix/name/filename)
 copy(R/'stage_A_r0/unit_verification.json',release/'validation/capacity/unit_verification.json')
 copy(R/'stage_A_synth_r0/running.json',release/'validation/capacity/SYN_A_running.json')
 copy(R/'stage_A_synth_r0/SYN.log',release/'validation/capacity/SYN_A.log')
 copy(R/'stage_A_synth_r0/fpga/component_inspector/td_project/camera_to_dsi_display_Runs/syn_1/camera_to_dsi_display_gate.area',release/'validation/capacity/SYN_A.area')
 # Preserve concrete failures and preflight iterations, without binary caches.
 for stage in ['stage_B_r0','stage_B_r1','stage_B_r2','stage_B_r3']:
  folder=R/stage
  for q in folder.glob('*.json'):copy(q,release/'validation/iterations'/stage/q.name)
  for q in folder.glob('*.log'):copy(q,release/'validation/iterations'/stage/q.name)
  for q in folder.rglob('compile.log'):
   if stage=='stage_B_r0':copy(q,release/'validation/iterations'/stage/q.relative_to(folder))
  if stage=='stage_B_r0':copy(folder/'source_snapshot/user_source/hdl_source/compact_inspector_osd.v',release/'validation/iterations'/stage/'failed_compact_inspector_osd.v')
 for stage in ['syn_1','phy_1']:
  for q in (P/'td_project/camera_to_dsi_display_Runs'/stage).iterdir():
   if q.is_file() and q.suffix in {'.area','.timing','.ts','.prj','.cfg','.tcl','.txt','.rpt','.log','.logw'}:copy(q,release/'build_evidence'/stage/q.name)
 tree(P/'classified_audit',release/'build_evidence/classified_audit');tree(R/'physical_r0/logs',release/'build_evidence/workflow',{'.log','.json'})
 copy(R/'physical_r0/running.json',release/'build_evidence/running.json')
 for q in R.glob('*.py'):copy(q,release/'scripts'/q.name)
 copy(Path('D:/CodexWork/classified_multithreshold_empty_20261022/prepare_portable_project.py'),release/'scripts/prepare_portable_project.py')
 for name in ['AGENTS.md','current_status.json','baseline_inputs.json','stage_A_changes.json','stage_B_scope.json']:copy(R/name,release/'handoff'/name)
 tree(R/'开发实施/验收记录',release/'handoff/verification_records',{'.md'})
 copy(bit,release/'candidate'/(NAME+'.bit'))
 guide=(R/'r13_guide_template.md').read_text(encoding='utf-8').replace('@@NAME@@',NAME).replace('@@SHA@@',sha(bit)).replace('@@TIMING@@',json.dumps(phy['timing_ns'])).replace('@@RESOURCE@@',json.dumps(resources)).replace('@@SLICE_PERCENT@@',f"{resources['slice']/21216*100:.2f}").replace('@@ERAM_PERCENT@@',f"{resources['eram']/108*100:.2f}")
 assert '@@' not in guide
 guidepath=release/(NAME+'_烧录与验收.md');guidepath.write_text(guide,encoding='utf-8')
 record=dict(name=NAME,status='SOFTWARE72_PLUS_CAPACITY_COMPACT_PIXEL_AND_ROUTED_PASS_HUMAN_BOARD_PENDING',source_manifest_sha256=sha(C/'inputs.json'),frozen_inputs=471,software_tests=72,capacity_contracts=3,compact_ui_pixels=3686400,native_references=10,rgb_source_frames=86,timing_ns=phy['timing_ns'],resources=resources,targets=dict(eram_le_96=resources['eram']<=96,slice_lt_90_percent=resources['slice']/21216<.9),bit_sha256=sha(bit),bit_bytes=bit.stat().st_size,hardware_programmed=False,field_count_proven=False,commit_push=False,created=datetime.datetime.now().isoformat())
 (release/'release_verification.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
 (release/'AGENTS.md').write_text('R13 resource/display capsule, no.git. Start with the Chinese guide and release_verification.json. All471 frozen inputs and72 strict compiled/runtime proofs plus unchanged vendor-RAM equivalence and four full720p UI references are present. Classifier/counter/ROI/SDC remain R12. UI is intentionally compact and Chinese; original legacy UI branch/default tests remain. Old failures and source iterations are retained. No new board count/speed acceptance. Automation/r12 stayPAUSED, no push or board operations. Historical progress snapshots do not supersede the final external Desktop receipt.\n',encoding='utf-8')
 payload={q.relative_to(release).as_posix():dict(bytes=q.stat().st_size,sha256=sha(q)) for q in release.rglob('*') if q.is_file()}
 (release/'PAYLOAD_SHA256.json').write_text(json.dumps(payload,indent=2),encoding='utf-8');archive=release.parent/(NAME+'_full.zip')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for q in sorted(release.rglob('*')):
   if q.is_file():z.write(q,q.relative_to(release).as_posix())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and set(z.namelist())==set(payload)|{'PAYLOAD_SHA256.json'}
  for rel,row in payload.items():
   data=z.read(rel);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],rel
 for src,dst in zip([bit,archive,guidepath],outputs):copy(src,dst)
 outputs[3].write_text(''.join(sha(q)+'  '+q.name+'\n' for q in outputs[:3]),encoding='utf-8')
 receipt=dict(record,status='DELIVERED_SHA_VERIFIED_PENDING_INDEPENDENT_RESTORE',archive_payload_entries=len(payload),expanded_release=str(release),desktop={str(q):dict(bytes=q.stat().st_size,sha256=sha(q)) for q in outputs[:4]})
 for q in [outputs[4],R/'delivery_receipt.json']:q.write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf-8')
 print('DELIVERED_SHA_VERIFIED',outputs[0],record['bit_sha256'],flush=True)
if __name__=='__main__':main()
