from pathlib import Path
import re,json,hashlib
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).parent;p=r/'development/fpga/component_inspector';h=p/'user_source/hdl_source';a=p/'sim/compact_assets';a.mkdir(exist_ok=True)
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
def write(q,s):q.write_text(s,encoding='ascii')
# Only seven CJK glyphs; existing five are copied bit for bit from R12.
ids={'有':1,'件':2,'空':3,'穴':4,'待':5,'复':6,'核':7}
old={int(i):int(v,16) for i,v in re.findall(r"memory\[(\d+)\]=24'h([0-9a-f]+)", (h/'osd_cjk_rom.v').read_text())}
oldids={'有':18,'件':19,'空':20,'穴':21,'待':17}
font=Path('C:/Windows/Fonts/msyh.ttc');values=[0]*256
for ch,i in ids.items():
 if ch in oldids:
  for y in range(24):values[i*32+y]=old[oldids[ch]*32+y]
 else:
  im=Image.new('L',(24,24));d=ImageDraw.Draw(im);f=ImageFont.truetype(str(font),23);b=d.textbbox((0,0),ch,font=f)
  d.text(((24-(b[2]-b[0]))//2-b[0],(24-(b[3]-b[1]))//2-b[1]),ch,font=f,fill=255)
  for y in range(24):values[i*32+y]=sum((im.getpixel((x,y))>=100)<<(23-x) for x in range(24))
def rom(name,width,vals):
 bits=(len(vals)-1).bit_length();digits=(width+3)//4
 write(h/(name+'.v'),f'// Generated compact UI immutable assets.\nmodule {name}(input wire clk,input wire [{bits-1}:0] address,output reg [{width-1}:0] data);\nreg [{width-1}:0] memory[0:{len(vals)-1}];\ninitial begin\n'+''.join(f"memory[{i}]={width}'h{v:0{digits}x};\n" for i,v in enumerate(vals))+'end\nalways @(posedge clk)data<=memory[address];\nendmodule\n')
 (a/(name+'.hex')).write_text(''.join(f'{v:0{digits}x}\n' for v in vals),encoding='ascii')
rom('compact_cjk_rom',24,values)
# Preserve every populated R12 ASCII glyph, fill only absent printable glyphs.
old_ascii={int(i):int(v,16) for i,v in re.findall(r"memory\[(\d+)\]=8'h([0-9a-f]+)", (h/'osd_ascii_rom.v').read_text())}
av=[old_ascii[i] for i in range(2048)];afont=Path('C:/Windows/Fonts/consola.ttf')
for ch in range(33,127):
 if any(av[ch*16:ch*16+16]):continue
 im=Image.new('L',(8,16));d=ImageDraw.Draw(im);f=ImageFont.truetype(str(afont),14);b=d.textbbox((0,0),chr(ch),font=f)
 d.text(((8-(b[2]-b[0]))//2-b[0],(16-(b[3]-b[1]))//2-b[1]),chr(ch),font=f,fill=255)
 for y in range(16):av[ch*16+y]=sum((im.getpixel((x,y))>=100)<<(7-x) for x in range(8))
rom('compact_ascii_rom',8,av)
# 2048x10 is one 20k ERAM. Tokens: literal/BCD/hex/special, five-bit field,
# three-bit digit. The rendered text plane is distributed, read asynchronously.
tokens=[32]*2048;manifest=[]
for page in range(2):
 rows=[[32]*128 for _ in range(7)];descriptions=[]
 def put(line,col,text):
  start=col
  for ch in text:
   if ch in ids:
    for offset in range(3):rows[line][col]=128+offset*16+ids[ch];col+=1
   else:assert ord(ch)<128;rows[line][col]=ord(ch);col+=1
  assert col<=128
  descriptions.append([line,start,text])
 def field(line,col,mode,slot,n):
  assert 1<=n<=8
  for k in range(n):rows[line][col+k]=mode*256+slot*8+(n-1-k)
  descriptions.append([line,col,{'mode':mode,'slot':slot,'digits':n}])
 put(0,0,'COUNT R13' if page else 'DETECT R13');put(0,12,'EXP');field(0,16,1,14,5);put(0,23,'GAIN');field(0,28,1,15,5)
 put(0,35,'FPS');field(0,39,1,16,3);put(0,44,'MODE');field(0,49,3,7,1)
 put(0,52,'WB');field(0,55,1,21,3);put(0,58,'/');field(0,59,1,22,3);field(0,63,3,8,1)
 put(0,67,'CFG');field(0,71,3,6,1);put(0,74,'V');field(0,76,3,5,1)
 if page:
  field(1,0,3,1,8);put(1,10,'TOTAL');field(1,16,1,0,3)
  put(1,22,'有件');field(1,29,1,1,3);put(1,35,'空穴');field(1,42,1,2,3)
  put(1,48,'待复核');field(1,58,1,3,3);put(1,64,'C');field(1,66,3,2,1)
  put(2,0,'RUN');field(2,4,1,4,5);put(2,12,'LAST');field(2,17,3,11,1);field(2,18,1,5,3)
  field(2,25,3,10,8);field(2,34,3,19,1);field(2,35,1,20,3);field(2,39,3,12,8);field(2,47,3,17,7)
  put(2,58,'FIRST');field(2,64,2,2,4)
  put(3,0,'EMPTY IDS PAGE');field(3,15,1,17,3);put(3,20,':')
  for i in range(8):field(3,23+i*5,1,6+i,3)
  put(4,0,'LAST');field(4,6,3,13,8);field(4,14,3,18,1);put(4,18,'WHY');field(4,22,2,14,1)
  put(4,26,'REVIEW = PRESENT SUBSET');put(4,53,'ROI');field(4,57,3,4,1);put(4,60,'DIR');field(4,64,3,3,1)
 else:
  put(1,0,'GRAY');field(1,5,1,23,3);put(1,10,'MIN');field(1,14,1,24,3);put(1,19,'MAX');field(1,23,1,25,3)
  put(1,30,'OBJ W');field(1,36,1,26,3);put(1,41,'H');field(1,43,1,27,3);put(1,48,'A');field(1,50,1,28,5)
  put(2,0,'UI OBS P');field(2,9,3,9,1);put(2,12,'E');field(2,14,3,14,1);put(2,17,'U');field(2,19,3,15,1)
  put(2,23,'2/ROI');put(2,31,'WAIT');field(2,36,2,13,1);put(2,40,'EDGE');field(2,45,1,31,5)
  put(3,0,'CAL1 M');field(3,7,2,16,2);put(3,11,'MIN');field(3,15,2,17,2);put(3,19,'MAX');field(3,23,2,18,2)
  put(3,27,'W');field(3,29,2,19,2);put(3,33,'H');field(3,35,2,20,2);put(3,39,'A');field(3,41,2,21,4);put(3,47,'CLIP');field(3,52,2,22,1)
  put(4,0,'CAL2 M');field(4,7,2,23,2);put(4,11,'MIN');field(4,15,2,24,2);put(4,19,'MAX');field(4,23,2,25,2)
  put(4,27,'W');field(4,29,2,26,2);put(4,33,'H');field(4,35,2,27,2);put(4,39,'A');field(4,41,2,28,4);put(4,47,'CLIP');field(4,52,2,29,1)
  put(4,56,'CAL V');field(4,62,3,16,1)
 for line in [5,6]:
  pass
 put(5,0,'SRC');field(5,4,2,0,8);put(5,15,'IN');field(5,18,1,29,4);put(5,22,'X');field(5,23,1,30,4)
 put(5,30,'OF');field(5,33,2,3,4);put(5,39,'UF');field(5,42,2,4,4);put(5,48,'LOST');field(5,53,2,5,4)
 put(5,60,'FIRST');field(5,66,2,2,4)
 put(6,0,'L');field(6,2,2,6,4);put(6,8,'F');field(6,10,2,7,4);put(6,16,'I');field(6,18,2,8,4)
 put(6,24,'G');field(6,26,2,9,4);put(6,32,'D');field(6,34,2,12,1);field(6,35,2,10,8);put(6,44,'P');field(6,46,2,11,8)
 put(6,57,'FR');field(6,60,2,1,8)
 for i,row in enumerate(rows):tokens[page*1024+i*128:page*1024+(i+1)*128]=row
 manifest.append({'page':page,'fields':descriptions})
rom('compact_template_rom',10,tokens)
(a/'layout.json').write_text(json.dumps({'width':1280,'height':720,'text_x':136,'text_y':[8,32,56,632,656,680,704],'logo':[16,8,96,64],'glyph_ids':ids,'font_sha256':sha(font),'pages':manifest,'notes':['CAL values and transport counters are hexadecimal. EXP/GAIN/FPS/counts are decimal.','UI OBS is two UI records per ROI, not four recorder observations.','REVIEW is a PRESENT subset. GAP means subsequent R numbers are record order, physical IDs unconfirmed.','Text metadata latches on first active pixel, publishes text before y8, no midframe changes.','Class labels use only source-frame objects already eligible in the original path.']},ensure_ascii=False,indent=2),encoding='utf-8')
print('Generated compact fonts/template and frozen layout specification')
