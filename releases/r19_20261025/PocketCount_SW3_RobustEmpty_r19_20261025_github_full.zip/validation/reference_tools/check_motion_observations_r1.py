"""Independent physical identity/source-event checks for controlled RGB inputs.
The fixtures declare15 physical positions, with EMPTY003/014. These are not
field RAW reconstructions and cannot establish board counting accuracy.
"""
from pathlib import Path
import json,hashlib,re,argparse,importlib.util

PROFILES={'robust_empty15_clear':(14,0,1),'robust_empty15_14':(14,4,1),
          'robust_empty15_17':(17,4,1),'robust_empty15_25':(25,4,1),
          'robust_empty15_left':(14,4,0)}
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')
def record(v):
 return {'valid':(v>>75)&1,'kind':(v>>73)&3,'reason':(v>>69)&15,
         'x0':(v>>31)&2047,'x1':(v>>20)&2047,'y0':(v>>10)&1023,'y1':v&1023}
def verify(tests,output):
 report={'status':'PASS_INDEPENDENT_FINITE15_PHYSICAL_IDS_AND_REAL_OBSERVED_EVENT_SOURCES','profiles':{},'field_accuracy':'NOT_ASSERTED'}
 for name,(speed,blur,right) in PROFILES.items():
  p=Path(tests[name]['origin'])/'sim/modelsim_work'/name/'console.log';log=read(p)
  assert 'PASS EMPTY15_MOTION:' in log and '** Fatal:' not in log,name
  frames=re.findall(r'PIXEL_OBSERVATIONS source=(\d+) data=([\da-fA-F]+)',log)
  assert [int(f) for f,_ in frames]==list(range(1,1350//speed+2)),name
  # Public recorder pipeline contract explicitly uses HYST4, unlike standalone counter default3.
  upstream=set();crossings={};checked=[];observations=0
  for sf,packet in frames:
   f=int(sf);offset=(f-1)*speed;lead=350+offset if right else 930-offset
   v=int(packet,16);seen=set()
   for i in range(4):
    r=record((v>>(76*i))&((1<<76)-1))
    if not r['valid'] or r['kind']<2:continue
    cx=(r['x0']+r['x1'])//2;cy=(r['y0']+r['y1'])//2
    distances=[abs(cx-(lead-(j-1)*64 if right else lead+(j-1)*64)) for j in range(1,16)]
    j=distances.index(min(distances))+1
    assert min(distances)<=3 and 317<=cy<=323,(name,f,j,r)
    assert j not in seen,(name,f,'duplicate physical observation',j)
    assert r['kind']==(3 if j in {3,14} else 2),(name,f,j,r)
    seen.add(j);observations+=1
    if (cx<636 if right else cx>644):upstream.add(j)
    if j in upstream and (cx>644 if right else cx<636) and j not in crossings:
     crossings[j]=f
   checked.append({'source':f,'physical_ids':sorted(seen)})
  actual=[tuple(map(int,row)) for row in re.findall(r'EVENT new source=(\d+) id=(\d+) class=(\d+) reason=[\da-fA-F]+',log)]
  assert set(crossings)==set(range(1,16)),(name,crossings)
  expected=[(crossings[j],j,3 if j in {3,14} else 2) for j in range(1,16)]
  assert actual==expected,(name,actual,expected)
  old=[tuple(map(int,row)) for row in re.findall(r'EVENT R18 source=(\d+) id=(\d+) class=(\d+) reason=[\da-fA-F]+',log)]
  if name=='robust_empty15_14':assert len(old)==14 and sum(k==3 for _,_,k in old)==1,(name,old)
  if name=='robust_empty15_clear':assert len(old)==15 and sum(k==3 for _,_,k in old)==2,(name,old)
  report['profiles'][name]={'speed_pixels_per_source':speed,'blur_radius':blur,'rightward':right,'source_frames':len(frames),'actual_observations':observations,'events':actual,'old_events':old,'frames':checked,'console_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 p=Path(tests['robust_empty_ab']['origin'])/'sim/modelsim_work/robust_empty_ab/console.log';log=read(p)
 rows=[tuple(map(int,v)) for v in re.findall(r'AB case=(\d+) old_empty=(\d+) new_empty=(\d+) expected=(\d+)',log)]
 assert [r[0] for r in rows]==list(range(24))
 assert all(new==want==(1 if n<12 else 0) for n,old,new,want in rows)
 assert sum(r[1] for r in rows)==10 and sum(r[2] for r in rows)==12
 report['shape_ab']={'cases':24,'positive':12,'negative':12,'rows':rows,'console_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 output.write_text(json.dumps(report,indent=2),encoding='utf8');return report
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--tests',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args()
 print(verify(json.loads(v.tests.read_text(encoding='utf8'))['tests'],v.output)['status'])
