"""Verify frozen inputs, actual compile commands, and test completion evidence.

No elaboration exemptions: every RTL/testbench file actually listed by vlog
must have exactly the final candidate's digest, even when a parameter is off.
"""
from pathlib import Path
import argparse, hashlib, json, re

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    b = p.read_bytes()
    return b.decode('utf-16' if b.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')

def verify(manifest_path, source, config_path, output):
    manifest = json.loads(read(manifest_path))
    for rel, digest in manifest.items():
        assert sha(source / rel) == digest, ('Frozen input changed', rel)
    config = json.loads(read(config_path))
    required = config['required_tests']
    assert len(required)==72 and set(required)==set(['classified_counter', 'classified_pages', 'classified_image', 'classified_controls', 'classified_page', 'regions', 'field180', 'cal180_holes', 'pose180', 'stable_ids_osd', 'classified_raw_motion', 'classified_raw_chain', 'raw_timing_probe', 'base_picture_repeatability', 'frame_tailproof', 'isp_metadata_stop', 'isp_writer_stop', 'hd_pins', 'hd_scaled_guard', 'hd_resize', 'manual_wb', 'fixed_wb', 'controls', 'wb_controls', 'classified_empty_guard', 'classified_empty_leading', 'classified_observed_page', 'empty_candidate_probe', 'empty_probe_pipeline', 'empty_probe_page', 'classified_bright_guard', 'classified_bright_motion', 'result_recorder', 'switch_recorder_controls', 'result_recorder_pipeline', 'result_recorder_raw_motion', 'result_recorder_page', 'motion_recovery', 'motion_recovery_raw', 'motion_recovery_page', 'tail_recovery', 'tail_recovery_raw', 'ordered_handoff', 'ordered_candidates', 'ordered_pipeline', 'ordered_raw_motion', 'hold_recovery', 'recovery_protection', 'recovery_pipeline', 'recovery_page', 'recovery_raw_motion', 'start_speed', 'velocity_recovery', 'velocity_pipeline', 'start_entry_raw', 'speed_raw', 'velocity_bootstrap', 'local_recovery', 'local_short', 'local_missing', 'local_ambiguity', 'local_left', 'local_pipeline', 'local_page', 'local_raw_motion', 'local_stream', 'local_capacity', 'dual_phase', 'dual_guard', 'dual_motion', 'dual_raw_motion', 'dual_page']), "Immutable67 plus5 dual-threshold contracts required"
    tests = {}
    for origin in config['origins']:
        project = Path(origin['project'])
        runtime_inputs = {}
        for rel, digest in manifest.items():
            if rel.startswith('sim/') and Path(rel).suffix.lower() in ('.hex', '.mif', '.dat'):
                assert sha(project / rel) == digest, ('Runtime font/reference data changed', origin['project'], rel)
                runtime_inputs[rel] = digest
        runner = read(project / 'sim/run_modelsim.ps1')
        sentinels = dict(re.findall(r'Name="([^"]+)";\s*Pass="([^"]+)"', runner))
        for name in origin['tests']:
            assert name in required and name not in tests, name
            root = project / 'sim/modelsim_work' / name
            compile_log = read(root / 'compile.log')
            console = read(root / 'console.log')
            assert sentinels[name] in console, ('No successful test sentinel', name)
            assert not re.search(r'\*\* (Fatal|Error):|Errors:\s*[1-9]', compile_log + console), name
            assert re.search(r'Errors:\s*0,\s*Warnings:', console), ('No simulator completion', name)
            inputs = {}
            for line in compile_log.splitlines():
                if 'vlog ' not in line or '-work' not in line:
                    continue
                for token in line.split():
                    if token.endswith(('.v', '.sv')):
                        p = (project / 'sim' / token).resolve()
                        rel = p.relative_to(project).as_posix()
                        digest = sha(p)
                        assert manifest.get(rel) == digest, ('Compiled input differs', name, rel)
                        inputs[rel] = digest
            assert inputs, ('No actual compiled input evidence', name)
            tests[name] = {'origin': str(project), 'inputs': inputs,
                           'runtime_inputs': runtime_inputs,
                           'console_sha256': sha(root / 'console.log'),
                           'compile_sha256': sha(root / 'compile.log'),
                           'pass_lines': [line for line in console.splitlines() if 'PASS ' in line]}
    assert set(tests) == set(required), ('Missing required tests', set(required) - set(tests))
    result = {'status': 'PASS72_FROZEN_ACTUAL_COMPILED_INPUTS_NO_EXCLUSIONS',
              'manifest_sha256': sha(manifest_path), 'source_count': len(manifest),
              'tests': tests, 'physical_count': 'HUMAN_KNOWN_SEQUENCE_ACCEPTANCE_PENDING'}
    output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--runs', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.manifest, args.source, args.runs, args.output)
    print(result['status'], len(result['tests']), 'tests,', result['source_count'], 'frozen inputs')
